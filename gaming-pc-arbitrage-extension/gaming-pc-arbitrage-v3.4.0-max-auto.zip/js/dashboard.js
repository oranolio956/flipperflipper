// Dashboard v3.2.0 - Production Ready
// Apple-level UI with working navigation and real Chrome storage integration

(function() {
  'use strict';

  // Initialize router
  const router = window.Router;
  const ROUTES = window.ROUTES;
  const NAV_GROUPS = window.NAV_GROUPS;

  // State management
  let appState = {
    currentRoute: '/',
    settings: {},
    listings: [],
    stats: {
      totalListings: 0,
      activeDeals: 0,
      revenue: 0,
      avgROI: 0,
      hitRate: 0
    }
  };

  // UI Components
  class DashboardApp {
    constructor() {
      this.root = document.getElementById('root');
      this.init();
    }

    async init() {
      // Load data from storage
      await this.loadData();
      
      // Set up routing
      router.subscribe(this.handleRouteChange.bind(this));
      
      // Render initial UI
      this.render();
      
      // Set up event listeners
      this.attachEventListeners();
      
      // Listen for storage changes
      chrome.storage.onChanged.addListener(this.handleStorageChange.bind(this));
    }

    async loadData() {
      try {
        const data = await chrome.storage.local.get(['settings', 'listings', 'deals']);
        appState.settings = data.settings || {};
        appState.listings = data.listings || [];
        
        // Calculate stats
        this.calculateStats(data);
      } catch (e) {
        console.error('Failed to load data:', e);
      }
    }

    calculateStats(data) {
      const deals = data.deals || [];
      const listings = data.listings || [];
      
      appState.stats = {
        totalListings: listings.length,
        activeDeals: deals.filter(d => d.status === 'active').length,
        revenue: deals.reduce((sum, d) => sum + (d.soldPrice || 0) - (d.purchasePrice || 0), 0),
        avgROI: deals.length > 0 
          ? deals.reduce((sum, d) => sum + ((d.soldPrice || 0) - (d.purchasePrice || 0)) / (d.purchasePrice || 1) * 100, 0) / deals.length
          : 0,
        hitRate: listings.length > 0 
          ? (deals.length / listings.length * 100)
          : 0
      };
    }

    handleStorageChange(changes, area) {
      if (area === 'local') {
        // Reload data on changes
        this.loadData().then(() => {
          // Re-render current page
          this.renderContent();
        });
      }
    }

    handleRouteChange({ path, params }) {
      appState.currentRoute = path;
      this.renderContent();
    }

    render() {
      this.root.innerHTML = `
        <div class="app-container">
          ${this.renderSidebar()}
          <div class="main-container">
            ${this.renderTopBar()}
            <main class="content" id="content">
              ${this.renderContent()}
            </main>
          </div>
          ${this.renderVersionHUD()}
        </div>
      `;
    }

    renderSidebar() {
      return `
        <aside class="sidebar">
          <div class="sidebar-header">
            <h1>PC Arbitrage Pro</h1>
            <span class="version-badge">v3.2.0</span>
          </div>
          
          <nav class="nav-sections">
            ${NAV_GROUPS.map(group => `
              <div class="nav-group">
                <h3 class="nav-group-title">${group.label}</h3>
                <div class="nav-links">
                  ${group.routes.map(routeKey => {
                    const route = ROUTES[routeKey];
                    const isActive = appState.currentRoute === route.path;
                    return `
                      <a href="#${route.path}" 
                         class="nav-link ${isActive ? 'active' : ''}"
                         data-testid="${route.testId}">
                        <span class="nav-icon">${this.getIcon(route.icon)}</span>
                        <span class="nav-text">${route.title}</span>
                      </a>
                    `;
                  }).join('')}
                </div>
              </div>
            `).join('')}
          </nav>
        </aside>
      `;
    }

    renderTopBar() {
      const currentRoute = router.getRoute(appState.currentRoute);
      const title = currentRoute ? currentRoute.title : 'Dashboard';
      
      return `
        <header class="top-bar">
          <div class="top-bar-left">
            <h2 class="page-title" data-testid="page-title">${title}</h2>
          </div>
          
          <div class="top-bar-actions">
            <button class="btn-icon" id="btn-dashboard" title="Dashboard">
              ${this.getIcon('dashboard')}
            </button>
            <button class="btn-icon" id="btn-settings" title="Settings">
              ${this.getIcon('settings')}
            </button>
          </div>
        </header>
      `;
    }

    renderContent() {
      const content = document.getElementById('content') || this.root;
      
      switch (appState.currentRoute) {
        case '/':
          content.innerHTML = this.renderDashboard();
          break;
        case '/scanner':
          content.innerHTML = this.renderScanner();
          break;
        case '/pipeline':
          content.innerHTML = this.renderPipeline();
          break;
        case '/settings':
          content.innerHTML = this.renderSettings();
          break;
        case '/automation':
          content.innerHTML = this.renderAutomation();
          break;
        default:
          content.innerHTML = this.renderComingSoon();
      }
      
      // Attach page-specific event listeners
      this.attachPageListeners();
    }

    renderDashboard() {
      return `
        <div class="dashboard">
          <div class="stats-grid">
            <div class="stat-card">
              <h3>Total Listings</h3>
              <p class="stat-value">${appState.stats.totalListings}</p>
              <p class="stat-change">Scanned today</p>
            </div>
            
            <div class="stat-card">
              <h3>Active Deals</h3>
              <p class="stat-value">${appState.stats.activeDeals}</p>
              <p class="stat-change">In pipeline</p>
            </div>
            
            <div class="stat-card">
              <h3>Revenue</h3>
              <p class="stat-value">$${appState.stats.revenue.toFixed(2)}</p>
              <p class="stat-change">Total profit</p>
            </div>
            
            <div class="stat-card">
              <h3>Avg ROI</h3>
              <p class="stat-value">${appState.stats.avgROI.toFixed(1)}%</p>
              <p class="stat-change">Per deal</p>
            </div>
          </div>
          
          <div class="quick-actions">
            <button class="btn btn-primary" id="btn-scan-now">Scan Current Page</button>
            <button class="btn btn-secondary" id="btn-toggle-auto">
              ${appState.settings.automation?.enabled ? 'Disable' : 'Enable'} Automation
            </button>
            <button class="btn btn-secondary" id="btn-view-pipeline">View Pipeline</button>
          </div>
          
          <div class="recent-section">
            <h3>Recent Listings</h3>
            <div class="listings-grid">
              ${appState.listings.slice(0, 6).map(listing => `
                <div class="listing-card">
                  <h4>${listing.title || 'Untitled'}</h4>
                  <p class="price">$${listing.price || 0}</p>
                  <p class="platform">${listing.platform || 'Unknown'}</p>
                  <p class="date">${this.formatDate(listing.foundAt)}</p>
                </div>
              `).join('') || '<p class="empty-state">No listings found. Start scanning!</p>'}
            </div>
          </div>
        </div>
      `;
    }

    renderScanner() {
      return `
        <div class="scanner-page">
          <div class="scanner-header">
            <h3>Marketplace Scanner</h3>
            <p>Scan Facebook Marketplace, Craigslist, and OfferUp for gaming PC deals</p>
          </div>
          
          <div class="scanner-actions">
            <button class="btn btn-primary" id="btn-scan-current">
              Scan Current Tab
            </button>
            <button class="btn btn-secondary" id="btn-scan-all">
              Open & Scan All Saved Searches
            </button>
          </div>
          
          <div class="scan-status" id="scan-status"></div>
          
          <div class="saved-searches">
            <h3>Saved Searches</h3>
            <div class="search-list">
              ${this.renderSavedSearches()}
            </div>
            <button class="btn btn-secondary" id="btn-add-search">
              Add New Search
            </button>
          </div>
        </div>
      `;
    }

    renderSavedSearches() {
      const searches = appState.settings.savedSearches || [];
      if (searches.length === 0) {
        return '<p class="empty-state">No saved searches. Add one to get started!</p>';
      }
      
      return searches.map((search, index) => `
        <div class="search-item">
          <div class="search-info">
            <h4>${search.name}</h4>
            <p class="search-url">${search.url}</p>
            <p class="search-meta">Runs every ${search.interval || 30} minutes</p>
          </div>
          <div class="search-actions">
            <button class="btn-icon" data-action="scan" data-index="${index}">
              ${this.getIcon('scan')}
            </button>
            <button class="btn-icon" data-action="delete" data-index="${index}">
              ${this.getIcon('delete')}
            </button>
          </div>
        </div>
      `).join('');
    }

    renderPipeline() {
      const deals = appState.deals || [];
      
      return `
        <div class="pipeline-page">
          <div class="pipeline-header">
            <h3>Deal Pipeline</h3>
            <div class="pipeline-filters">
              <button class="filter-btn active">All</button>
              <button class="filter-btn">New</button>
              <button class="filter-btn">Contacted</button>
              <button class="filter-btn">Purchased</button>
              <button class="filter-btn">Listed</button>
              <button class="filter-btn">Sold</button>
            </div>
          </div>
          
          <div class="pipeline-grid">
            ${this.renderPipelineColumns()}
          </div>
        </div>
      `;
    }

    renderPipelineColumns() {
      const stages = ['new', 'contacted', 'negotiating', 'purchased', 'refurbishing', 'listed', 'sold'];
      
      return stages.map(stage => `
        <div class="pipeline-column" data-stage="${stage}">
          <h4 class="column-header">${this.formatStage(stage)}</h4>
          <div class="column-cards">
            <!-- Real deals would go here -->
            <p class="empty-state">No deals in ${stage}</p>
          </div>
        </div>
      `).join('');
    }

    renderSettings() {
      const settings = window.settingsManager.get();
      const tabs = [
        { id: 'automation', label: 'Automation', icon: '🤖' },
        { id: 'notifications', label: 'Notifications', icon: '🔔' },
        { id: 'display', label: 'Display', icon: '🎨' },
        { id: 'pricing', label: 'Pricing', icon: '💰' },
        { id: 'privacy', label: 'Privacy', icon: '🔒' }
      ];
      
      return `
        <div class="settings-page">
          <div class="settings-header">
            <div>
              <h3>Settings</h3>
              <p class="settings-subtitle">Configure your arbitrage assistant</p>
            </div>
            <div class="settings-actions">
              <button class="btn btn-secondary" id="btn-reset-all">
                ${this.getIcon('reset')} Reset All
              </button>
              <button class="btn btn-secondary" id="btn-export-settings">
                ${this.getIcon('download')} Export
              </button>
              <button class="btn btn-secondary" id="btn-import-settings">
                ${this.getIcon('upload')} Import
              </button>
              <button class="btn btn-primary" id="btn-save-settings" disabled>
                ${this.getIcon('save')} Save Changes
              </button>
            </div>
          </div>
          
          <div class="settings-content">
            <div class="settings-tabs">
              ${tabs.map(tab => `
                <button class="settings-tab ${tab.id === 'automation' ? 'active' : ''}" 
                        data-tab="${tab.id}">
                  <span class="tab-icon">${tab.icon}</span>
                  <span class="tab-label">${tab.label}</span>
                </button>
              `).join('')}
            </div>
            
            <div class="settings-panels">
              <!-- Automation Panel -->
              <div class="settings-panel active" data-panel="automation">
                <div class="panel-header">
                  <h4>Automation Settings</h4>
                  <button class="btn-text" data-reset="automation">Reset Section</button>
                </div>
                
                <div class="setting-group">
                  <label class="toggle-setting">
                    <div>
                      <span class="setting-label">Enable Max Auto</span>
                      <span class="setting-description">Automatically scan saved searches on schedule</span>
                    </div>
                    <input type="checkbox" 
                           data-path="automation.enabled"
                           ${settings.automation.enabled ? 'checked' : ''}>
                  </label>
                </div>
                
                <div class="setting-group">
                  <label class="input-setting">
                    <span class="setting-label">Scan Interval</span>
                    <span class="setting-description">How often to run automated scans (minutes)</span>
                    <input type="number" 
                           data-path="automation.scanInterval"
                           value="${settings.automation.scanInterval}" 
                           min="5" max="360">
                  </label>
                </div>
                
                <div class="setting-group">
                  <label class="range-setting">
                    <span class="setting-label">Max Concurrent Tabs</span>
                    <span class="setting-description">Maximum tabs to open simultaneously</span>
                    <div class="range-wrapper">
                      <input type="range" 
                             data-path="automation.maxConcurrentTabs"
                             value="${settings.automation.maxConcurrentTabs}" 
                             min="1" max="10">
                      <span class="range-value">${settings.automation.maxConcurrentTabs}</span>
                    </div>
                  </label>
                </div>
                
                <div class="setting-group">
                  <label class="toggle-setting">
                    <div>
                      <span class="setting-label">Pause During Active Use</span>
                      <span class="setting-description">Stop automation when you're actively browsing</span>
                    </div>
                    <input type="checkbox" 
                           data-path="automation.pauseDuringActive"
                           ${settings.automation.pauseDuringActive ? 'checked' : ''}>
                  </label>
                </div>
              </div>
              
              <!-- Notifications Panel -->
              <div class="settings-panel" data-panel="notifications">
                <div class="panel-header">
                  <h4>Notification Settings</h4>
                  <button class="btn-text" data-reset="notifications">Reset Section</button>
                </div>
                
                <div class="setting-group">
                  <label class="toggle-setting">
                    <div>
                      <span class="setting-label">Enable Notifications</span>
                      <span class="setting-description">Show notifications for important events</span>
                    </div>
                    <input type="checkbox" 
                           data-path="notifications.enabled"
                           ${settings.notifications.enabled ? 'checked' : ''}>
                  </label>
                </div>
                
                ${settings.notifications.enabled ? `
                  <div class="setting-group">
                    <label class="toggle-setting">
                      <div>
                        <span class="setting-label">Desktop Notifications</span>
                        <span class="setting-description">Show system notifications (requires permission)</span>
                      </div>
                      <input type="checkbox" 
                             data-path="notifications.desktop"
                             ${settings.notifications.desktop ? 'checked' : ''}>
                    </label>
                  </div>
                  
                  <div class="setting-group">
                    <label class="toggle-setting">
                      <div>
                        <span class="setting-label">Sound Alerts</span>
                        <span class="setting-description">Play sound when notifications appear</span>
                      </div>
                      <input type="checkbox" 
                             data-path="notifications.sound"
                             ${settings.notifications.sound ? 'checked' : ''}>
                    </label>
                  </div>
                  
                  <div class="setting-subsection">
                    <h5>Notification Triggers</h5>
                    
                    <label class="toggle-setting">
                      <div>
                        <span class="setting-label">New Deals</span>
                        <span class="setting-description">When profitable deals are found</span>
                      </div>
                      <input type="checkbox" 
                             data-path="notifications.triggers.newDeal"
                             ${settings.notifications.triggers.newDeal ? 'checked' : ''}>
                    </label>
                    
                    <label class="toggle-setting">
                      <div>
                        <span class="setting-label">Price Changes</span>
                        <span class="setting-description">When tracked listings change price</span>
                      </div>
                      <input type="checkbox" 
                             data-path="notifications.triggers.priceChange"
                             ${settings.notifications.triggers.priceChange ? 'checked' : ''}>
                    </label>
                  </div>
                ` : ''}
              </div>
              
              <!-- Display Panel -->
              <div class="settings-panel" data-panel="display">
                <div class="panel-header">
                  <h4>Display Settings</h4>
                  <button class="btn-text" data-reset="display">Reset Section</button>
                </div>
                
                <div class="setting-group">
                  <label class="setting-label">Theme</label>
                  <div class="theme-selector">
                    <button class="theme-option ${settings.display.theme === 'light' ? 'active' : ''}"
                            data-theme="light">
                      ${this.getIcon('sun')} Light
                    </button>
                    <button class="theme-option ${settings.display.theme === 'dark' ? 'active' : ''}"
                            data-theme="dark">
                      ${this.getIcon('moon')} Dark
                    </button>
                    <button class="theme-option ${settings.display.theme === 'auto' ? 'active' : ''}"
                            data-theme="auto">
                      ${this.getIcon('auto')} Auto
                    </button>
                  </div>
                </div>
                
                <div class="setting-group">
                  <label class="toggle-setting">
                    <div>
                      <span class="setting-label">Compact Mode</span>
                      <span class="setting-description">Show more information in less space</span>
                    </div>
                    <input type="checkbox" 
                           data-path="display.compactMode"
                           ${settings.display.compactMode ? 'checked' : ''}>
                  </label>
                </div>
              </div>
              
              <!-- Pricing Panel -->
              <div class="settings-panel" data-panel="pricing">
                <div class="panel-header">
                  <h4>Pricing Settings</h4>
                  <button class="btn-text" data-reset="pricing">Reset Section</button>
                </div>
                
                <div class="setting-group">
                  <label class="input-setting">
                    <span class="setting-label">Default Markup</span>
                    <span class="setting-description">Target profit margin (%)</span>
                    <input type="number" 
                           data-path="pricing.defaultMarkup"
                           value="${settings.pricing.defaultMarkup}" 
                           min="0" max="100">
                  </label>
                </div>
                
                <div class="setting-group">
                  <label class="toggle-setting">
                    <div>
                      <span class="setting-label">Include Shipping</span>
                      <span class="setting-description">Factor shipping costs in calculations</span>
                    </div>
                    <input type="checkbox" 
                           data-path="pricing.includeShipping"
                           ${settings.pricing.includeShipping ? 'checked' : ''}>
                  </label>
                </div>
                
                <div class="setting-group">
                  <label class="select-setting">
                    <span class="setting-label">Pricing Strategy</span>
                    <span class="setting-description">How aggressively to price items</span>
                    <select data-path="pricing.pricingStrategy">
                      <option value="aggressive" ${settings.pricing.pricingStrategy === 'aggressive' ? 'selected' : ''}>
                        Aggressive (Quick Sale)
                      </option>
                      <option value="moderate" ${settings.pricing.pricingStrategy === 'moderate' ? 'selected' : ''}>
                        Moderate (Balanced)
                      </option>
                      <option value="conservative" ${settings.pricing.pricingStrategy === 'conservative' ? 'selected' : ''}>
                        Conservative (Max Profit)
                      </option>
                    </select>
                  </label>
                </div>
              </div>
              
              <!-- Privacy Panel -->
              <div class="settings-panel" data-panel="privacy">
                <div class="panel-header">
                  <h4>Privacy Settings</h4>
                  <button class="btn-text" data-reset="privacy">Reset Section</button>
                </div>
                
                <div class="setting-group">
                  <label class="toggle-setting">
                    <div>
                      <span class="setting-label">Analytics</span>
                      <span class="setting-description">Help improve the extension with usage data</span>
                    </div>
                    <input type="checkbox" 
                           data-path="privacy.analytics"
                           ${settings.privacy.analytics ? 'checked' : ''}>
                  </label>
                </div>
                
                <div class="setting-group">
                  <label class="toggle-setting">
                    <div>
                      <span class="setting-label">Auto Backup</span>
                      <span class="setting-description">Automatically backup your data</span>
                    </div>
                    <input type="checkbox" 
                           data-path="privacy.autoBackup"
                           ${settings.privacy.autoBackup ? 'checked' : ''}>
                  </label>
                </div>
                
                <div class="setting-group">
                  <label class="input-setting">
                    <span class="setting-label">Data Retention</span>
                    <span class="setting-description">Days to keep old data</span>
                    <input type="number" 
                           data-path="privacy.dataRetention"
                           value="${settings.privacy.dataRetention}" 
                           min="7" max="365">
                  </label>
                </div>
              </div>
            </div>
          </div>
        </div>
      `;
    }

    renderAutomation() {
      const settings = window.settingsManager?.get() || appState.settings;
      const engineStatus = window.automationEngine?.getStatus() || {};
      
      return `
        <div class="automation-page">
          <div class="automation-header">
            <h3>Automation Center</h3>
            <div class="automation-status ${settings.automation?.enabled ? 'active' : 'inactive'}">
              <span class="status-indicator"></span>
              <span>Automation ${settings.automation?.enabled ? 'Active' : 'Inactive'}</span>
            </div>
          </div>
          
          <div class="automation-controls">
            ${engineStatus.isRunning ? `
              <button class="btn btn-danger" id="btn-stop-session">
                ${this.getIcon('stop')} Stop Current Session
              </button>
              ${engineStatus.isPaused ? `
                <button class="btn btn-primary" id="btn-resume-session">
                  ${this.getIcon('play')} Resume
                </button>
              ` : `
                <button class="btn btn-secondary" id="btn-pause-session">
                  ${this.getIcon('pause')} Pause
                </button>
              `}
            ` : `
              <button class="btn btn-primary" id="btn-start-session">
                ${this.getIcon('play')} Start Automation Session
              </button>
              <button class="btn btn-secondary" id="btn-manual-scan">
                ${this.getIcon('scan')} Run Once Now
              </button>
            `}
            
            <button class="btn btn-secondary" id="btn-view-history">
              ${this.getIcon('history')} View History
            </button>
          </div>
          
          ${engineStatus.currentSession ? `
            <div class="session-status">
              <h4>Current Session</h4>
              <div class="session-info">
                <div class="session-stats">
                  <div class="stat">
                    <span class="label">Total</span>
                    <span class="value">${engineStatus.currentSession.stats.total}</span>
                  </div>
                  <div class="stat">
                    <span class="label">Completed</span>
                    <span class="value">${engineStatus.currentSession.stats.completed}</span>
                  </div>
                  <div class="stat">
                    <span class="label">Failed</span>
                    <span class="value">${engineStatus.currentSession.stats.failed}</span>
                  </div>
                  <div class="stat">
                    <span class="label">New Listings</span>
                    <span class="value">${engineStatus.currentSession.stats.newListings}</span>
                  </div>
                </div>
                
                <div class="progress-bar">
                  <div class="progress-fill" style="width: ${
                    (engineStatus.currentSession.stats.completed / engineStatus.currentSession.stats.total) * 100
                  }%"></div>
                </div>
              </div>
              
              <div class="active-jobs">
                <h5>Active Jobs (${engineStatus.activeJobs.length})</h5>
                ${engineStatus.activeJobs.map(job => `
                  <div class="job-item">
                    <span class="job-name">${job.searchName}</span>
                    <span class="job-status">${job.status}</span>
                  </div>
                `).join('') || '<p class="empty-state">No active jobs</p>'}
              </div>
            </div>
          ` : ''}
          
          <div class="saved-searches-section">
            <h4>Saved Searches</h4>
            ${this.renderSavedSearchesForAutomation(settings)}
          </div>
          
          <div class="automation-logs">
            <h4>Recent Activity</h4>
            <div class="log-entries" id="automation-logs">
              ${this.renderAutomationLogs()}
            </div>
          </div>
        </div>
      `;
    }
    
    renderSavedSearchesForAutomation(settings) {
      const searches = settings.search?.savedSearches || [];
      
      if (searches.length === 0) {
        return `
          <p class="empty-state">No saved searches yet. 
            <a href="#/scanner" class="link">Add searches</a> to automate scanning.
          </p>
        `;
      }
      
      return `
        <div class="searches-grid">
          ${searches.map(search => `
            <div class="search-card ${search.enabled ? 'enabled' : 'disabled'}">
              <div class="search-header">
                <input type="checkbox" 
                       class="search-toggle" 
                       data-search-id="${search.id}"
                       ${search.enabled ? 'checked' : ''}>
                <h5>${search.name}</h5>
              </div>
              <p class="search-url">${search.url}</p>
              <p class="search-schedule">
                ${search.enabled 
                  ? `Runs every ${search.interval || settings.automation.scanInterval} minutes`
                  : 'Disabled'
                }
              </p>
              ${search.lastRun ? `
                <p class="search-last-run">
                  Last run: ${this.formatDate(search.lastRun)}
                </p>
              ` : ''}
            </div>
          `).join('')}
        </div>
      `;
    }
    
    renderAutomationLogs() {
      // Get recent scan history
      const history = JSON.parse(localStorage.getItem('recentAutomationEvents') || '[]');
      
      if (history.length === 0) {
        return '<p class="empty-state">No automation activity yet</p>';
      }
      
      return history.slice(0, 20).map(event => `
        <div class="log-entry ${event.type}">
          <span class="log-time">${new Date(event.timestamp).toLocaleTimeString()}</span>
          <span class="log-message">${event.message}</span>
        </div>
      `).join('');
    }

    renderComingSoon() {
      const route = router.getRoute(appState.currentRoute);
      return `
        <div class="coming-soon">
          <h3>${route ? route.title : 'Page'} - Coming Soon</h3>
          <p>This feature is currently being implemented with Apple-level quality.</p>
          <p>Check back in the next update!</p>
        </div>
      `;
    }

    renderVersionHUD() {
      return `
        <div class="version-hud" id="version-hud">
          <div class="version-main">
            <span class="version-text">v3.2.0</span>
            <span class="update-status">Up to date</span>
          </div>
          <div class="version-details" style="display: none;">
            <p>Build: ${Date.now().toString(36)}</p>
            <p>Channel: Stable</p>
          </div>
        </div>
      `;
    }

    attachEventListeners() {
      // Global navigation
      this.root.addEventListener('click', (e) => {
        // Handle nav links
        if (e.target.closest('.nav-link')) {
          e.preventDefault();
          const link = e.target.closest('.nav-link');
          const path = link.getAttribute('href').slice(1); // Remove #
          router.navigate(path);
        }
        
        // Quick action buttons
        if (e.target.id === 'btn-dashboard') {
          router.navigate('/');
        } else if (e.target.id === 'btn-settings') {
          router.navigate('/settings');
        }
        
        // Version HUD toggle
        if (e.target.closest('.version-hud')) {
          const details = this.root.querySelector('.version-details');
          details.style.display = details.style.display === 'none' ? 'block' : 'none';
        }
      });
    }

    attachPageListeners() {
      // Dashboard actions
      const scanBtn = document.getElementById('btn-scan-now');
      if (scanBtn) {
        scanBtn.addEventListener('click', () => {
          chrome.runtime.sendMessage({ action: 'SCAN_CURRENT_TAB' });
        });
      }
      
      const toggleAutoBtn = document.getElementById('btn-toggle-auto');
      if (toggleAutoBtn) {
        toggleAutoBtn.addEventListener('click', async () => {
          const enabled = !appState.settings.automation?.enabled;
          appState.settings.automation = { 
            ...appState.settings.automation, 
            enabled 
          };
          await chrome.storage.local.set({ settings: appState.settings });
          chrome.runtime.sendMessage({ 
            action: 'SETTINGS_UPDATED', 
            data: appState.settings 
          });
          this.renderContent();
        });
      }
      
      const pipelineBtn = document.getElementById('btn-view-pipeline');
      if (pipelineBtn) {
        pipelineBtn.addEventListener('click', () => {
          router.navigate('/pipeline');
        });
      }
      
      // Settings page
      if (appState.currentRoute === '/settings') {
        this.attachSettingsListeners();
      }
      
      // Scanner page
      const scanCurrentBtn = document.getElementById('btn-scan-current');
      if (scanCurrentBtn) {
        scanCurrentBtn.addEventListener('click', () => {
          chrome.runtime.sendMessage({ action: 'SCAN_CURRENT_TAB' });
          this.showScanStatus('Scanning current tab...');
        });
      }
      
      // Automation page
      if (appState.currentRoute === '/automation') {
        this.attachAutomationListeners();
      }
    }

    attachSettingsListeners() {
      let changedSettings = {};
      let hasChanges = false;
      
      // Tab switching
      document.querySelectorAll('.settings-tab').forEach(tab => {
        tab.addEventListener('click', (e) => {
          const tabId = e.currentTarget.dataset.tab;
          
          // Update tab states
          document.querySelectorAll('.settings-tab').forEach(t => t.classList.remove('active'));
          e.currentTarget.classList.add('active');
          
          // Update panel states
          document.querySelectorAll('.settings-panel').forEach(p => p.classList.remove('active'));
          document.querySelector(`[data-panel="${tabId}"]`)?.classList.add('active');
        });
      });
      
      // Input change tracking
      const trackChange = (path, value) => {
        // Navigate to nested property in changedSettings
        const keys = path.split('.');
        let current = changedSettings;
        
        for (let i = 0; i < keys.length - 1; i++) {
          if (!current[keys[i]]) current[keys[i]] = {};
          current = current[keys[i]];
        }
        
        current[keys[keys.length - 1]] = value;
        hasChanges = true;
        
        // Enable save button
        const saveBtn = document.getElementById('btn-save-settings');
        if (saveBtn) saveBtn.disabled = false;
      };
      
      // Checkbox handlers
      document.querySelectorAll('input[type="checkbox"][data-path]').forEach(input => {
        input.addEventListener('change', (e) => {
          trackChange(e.target.dataset.path, e.target.checked);
          
          // Handle desktop notifications permission
          if (e.target.dataset.path === 'notifications.desktop' && e.target.checked) {
            if (Notification.permission === 'default') {
              Notification.requestPermission();
            }
          }
          
          // Re-render if notifications toggled
          if (e.target.dataset.path === 'notifications.enabled') {
            this.renderContent();
          }
        });
      });
      
      // Number input handlers
      document.querySelectorAll('input[type="number"][data-path]').forEach(input => {
        input.addEventListener('input', (e) => {
          trackChange(e.target.dataset.path, parseInt(e.target.value) || 0);
        });
      });
      
      // Range input handlers
      document.querySelectorAll('input[type="range"][data-path]').forEach(input => {
        input.addEventListener('input', (e) => {
          const value = parseInt(e.target.value);
          trackChange(e.target.dataset.path, value);
          
          // Update display
          const valueDisplay = e.target.parentElement.querySelector('.range-value');
          if (valueDisplay) valueDisplay.textContent = value;
        });
      });
      
      // Select handlers
      document.querySelectorAll('select[data-path]').forEach(select => {
        select.addEventListener('change', (e) => {
          trackChange(e.target.dataset.path, e.target.value);
        });
      });
      
      // Theme selector
      document.querySelectorAll('.theme-option').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const theme = e.currentTarget.dataset.theme;
          trackChange('display.theme', theme);
          
          // Update UI
          document.querySelectorAll('.theme-option').forEach(b => b.classList.remove('active'));
          e.currentTarget.classList.add('active');
          
          // Apply theme immediately
          this.applyTheme(theme);
          
          // Enable save button
          const saveBtn = document.getElementById('btn-save-settings');
          if (saveBtn) saveBtn.disabled = false;
        });
      });
      
      // Save button
      const saveBtn = document.getElementById('btn-save-settings');
      if (saveBtn) {
        saveBtn.addEventListener('click', async () => {
          saveBtn.disabled = true;
          saveBtn.textContent = 'Saving...';
          
          try {
            await window.settingsManager.update(changedSettings);
            changedSettings = {};
            hasChanges = false;
            this.showToast('Settings saved successfully!');
            saveBtn.textContent = `${this.getIcon('save')} Save Changes`;
          } catch (error) {
            this.showToast('Failed to save settings', 'error');
            saveBtn.textContent = `${this.getIcon('save')} Save Changes`;
            saveBtn.disabled = false;
          }
        });
      }
      
      // Reset buttons
      document.querySelectorAll('[data-reset]').forEach(btn => {
        btn.addEventListener('click', async (e) => {
          const section = e.target.dataset.reset;
          if (confirm(`Reset ${section} settings to defaults?`)) {
            await window.settingsManager.reset(section);
            this.renderContent();
            this.showToast(`${section} settings reset to defaults`);
          }
        });
      });
      
      // Reset all button
      const resetAllBtn = document.getElementById('btn-reset-all');
      if (resetAllBtn) {
        resetAllBtn.addEventListener('click', async () => {
          if (confirm('Reset ALL settings to defaults? This cannot be undone.')) {
            await window.settingsManager.reset();
            this.renderContent();
            this.showToast('All settings reset to defaults');
          }
        });
      }
      
      // Export button
      const exportBtn = document.getElementById('btn-export-settings');
      if (exportBtn) {
        exportBtn.addEventListener('click', async () => {
          try {
            const data = await window.settingsManager.export();
            const blob = new Blob([data], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `arbitrage-settings-${new Date().toISOString().split('T')[0]}.json`;
            a.click();
            URL.revokeObjectURL(url);
            this.showToast('Settings exported successfully');
          } catch (error) {
            this.showToast('Failed to export settings', 'error');
          }
        });
      }
      
      // Import button
      const importBtn = document.getElementById('btn-import-settings');
      if (importBtn) {
        importBtn.addEventListener('click', () => {
          const input = document.createElement('input');
          input.type = 'file';
          input.accept = '.json';
          input.onchange = async (e) => {
            const file = e.target.files?.[0];
            if (!file) return;
            
            try {
              const text = await file.text();
              await window.settingsManager.import(text);
              this.renderContent();
              this.showToast('Settings imported successfully');
            } catch (error) {
              this.showToast('Failed to import settings - invalid format', 'error');
            }
          };
          input.click();
        });
      }
    }
    
    applyTheme(theme) {
      // Apply theme to document
      if (theme === 'auto') {
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        document.documentElement.setAttribute('data-theme', prefersDark ? 'dark' : 'light');
      } else {
        document.documentElement.setAttribute('data-theme', theme);
      }
    }

    showScanStatus(message) {
      const status = document.getElementById('scan-status');
      if (status) {
        status.innerHTML = `<p class="scan-message">${message}</p>`;
      }
    }

    attachAutomationListeners() {
      // Load automation engine if needed
      if (!window.automationEngine) {
        const script = document.createElement('script');
        script.src = 'js/automation-engine.js';
        document.head.appendChild(script);
      }
      
      // Subscribe to engine events
      if (window.automationEngine) {
        const unsubscribe = window.automationEngine.subscribe((event) => {
          this.handleAutomationEvent(event);
        });
        
        // Store unsubscribe for cleanup
        this.automationUnsubscribe = unsubscribe;
      }
      
      // Start session button
      const startBtn = document.getElementById('btn-start-session');
      if (startBtn) {
        startBtn.addEventListener('click', async () => {
          try {
            await window.automationEngine.startSession();
            this.renderContent();
          } catch (error) {
            this.showToast(error.message, 'error');
          }
        });
      }
      
      // Stop session button
      const stopBtn = document.getElementById('btn-stop-session');
      if (stopBtn) {
        stopBtn.addEventListener('click', async () => {
          await window.automationEngine.stopSession();
          this.renderContent();
        });
      }
      
      // Pause/Resume buttons
      const pauseBtn = document.getElementById('btn-pause-session');
      if (pauseBtn) {
        pauseBtn.addEventListener('click', () => {
          window.automationEngine.setPaused(true);
          this.renderContent();
        });
      }
      
      const resumeBtn = document.getElementById('btn-resume-session');
      if (resumeBtn) {
        resumeBtn.addEventListener('click', () => {
          window.automationEngine.setPaused(false);
          this.renderContent();
        });
      }
      
      // Manual scan button
      const manualBtn = document.getElementById('btn-manual-scan');
      if (manualBtn) {
        manualBtn.addEventListener('click', async () => {
          try {
            // Run all enabled searches once
            await window.automationEngine.startSession();
          } catch (error) {
            this.showToast(error.message, 'error');
          }
        });
      }
      
      // View history button
      const historyBtn = document.getElementById('btn-view-history');
      if (historyBtn) {
        historyBtn.addEventListener('click', async () => {
          const history = await window.automationEngine.getScanHistory();
          console.log('Scan history:', history);
          // TODO: Show history modal
        });
      }
      
      // Search toggles
      document.querySelectorAll('.search-toggle').forEach(toggle => {
        toggle.addEventListener('change', async (e) => {
          const searchId = e.target.dataset.searchId;
          const enabled = e.target.checked;
          
          await window.settingsManager.updateSavedSearch(searchId, { enabled });
          this.showToast(`Search ${enabled ? 'enabled' : 'disabled'}`);
        });
      });
    }
    
    handleAutomationEvent(event) {
      console.log('[Dashboard] Automation event:', event);
      
      // Log event
      const events = JSON.parse(localStorage.getItem('recentAutomationEvents') || '[]');
      events.unshift({
        type: event.type,
        timestamp: new Date().toISOString(),
        message: this.getEventMessage(event)
      });
      localStorage.setItem('recentAutomationEvents', JSON.stringify(events.slice(0, 100)));
      
      // Update UI if on automation page
      if (appState.currentRoute === '/automation') {
        this.renderContent();
      }
      
      // Show notifications for important events
      if (event.type === 'session_completed') {
        this.showToast(`Scan complete: ${event.session.stats.newListings} new listings found`);
      }
    }
    
    getEventMessage(event) {
      switch (event.type) {
        case 'session_started':
          return `Started scanning ${event.session.stats.total} searches`;
        case 'session_stopped':
          return 'Scanning stopped by user';
        case 'session_completed':
          return `Completed ${event.session.stats.completed} searches, found ${event.session.stats.newListings} new listings`;
        case 'session_paused':
          return 'Scanning paused';
        case 'session_resumed':
          return 'Scanning resumed';
        case 'job_started':
          return `Scanning ${event.job.searchName}`;
        case 'job_completed':
          return `Completed ${event.job.searchName} - ${event.job.resultsCount} results`;
        case 'job_failed':
          return `Failed ${event.job.searchName}: ${event.job.error}`;
        default:
          return event.type;
      }
    }
    
    showToast(message, type = 'success') {
      const toast = document.createElement('div');
      toast.className = `toast toast-${type}`;
      toast.textContent = message;
      document.body.appendChild(toast);
      
      setTimeout(() => {
        toast.classList.add('show');
      }, 10);
      
      setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
      }, 3000);
    }

    formatDate(dateStr) {
      if (!dateStr) return 'Unknown';
      const date = new Date(dateStr);
      const now = new Date();
      const diff = now - date;
      
      if (diff < 60000) return 'Just now';
      if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
      if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
      return `${Math.floor(diff / 86400000)}d ago`;
    }

    formatStage(stage) {
      return stage.charAt(0).toUpperCase() + stage.slice(1);
    }

    getIcon(name) {
      // Simple SVG icons
      const icons = {
        dashboard: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>',
        scan: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2"/><line x1="7" y1="12" x2="17" y2="12"/></svg>',
        settings: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M12 1v6m0 6v6m9-9h-6m-6 0H3"/></svg>',
        pipeline: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>',
        delete: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18m-2 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
        save: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>',
        reset: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>',
        download: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
        upload: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>',
        sun: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>',
        moon: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>',
        auto: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="18" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>',
        play: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>',
        pause: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>',
        stop: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18"/></svg>',
        history: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2a10 10 0 1 0 10 10"/><polyline points="12 6 12 12 16 14"/><path d="m22 2-6 6"/><path d="m16 2 6 6"/></svg>'
      };
      
      return icons[name] || '';
    }
  }

  // Initialize app
  document.addEventListener('DOMContentLoaded', () => {
    window.app = new DashboardApp();
    
    // Add manual test runner
    window.runRoutingTest = async function() {
      console.log('🧪 Running Routing Tests...\n');
      const results = [];
      
      // Test 1: Navigation links
      const navLinks = document.querySelectorAll('.nav-link');
      results.push({
        test: 'Navigation links present',
        pass: navLinks.length === 15,
        actual: navLinks.length
      });
      
      // Test 2: Click Scanner
      const scanner = document.querySelector('[data-testid="route-scanner"]');
      scanner.click();
      await new Promise(r => setTimeout(r, 100));
      
      const title = document.querySelector('[data-testid="page-title"]').textContent;
      results.push({
        test: 'Scanner navigation',
        pass: title === 'Scanner',
        actual: title
      });
      
      // Test 3: Dashboard button
      document.getElementById('btn-dashboard').click();
      await new Promise(r => setTimeout(r, 100));
      
      const dashTitle = document.querySelector('[data-testid="page-title"]').textContent;
      results.push({
        test: 'Dashboard quick action',
        pass: dashTitle === 'Dashboard',
        actual: dashTitle
      });
      
      console.log('Results:', results);
      return results;
    };
  });
})();