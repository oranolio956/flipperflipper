// Background Service Worker v3.2.0 - Settings-Aware
// Reacts to settings changes and drives automation behavior

let settings = null;
let automationAlarm = null;

// Initialize on install
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log('[Background] Extension installed:', details.reason);
  
  // Load settings
  await loadSettings();
  
  // Create context menu
  chrome.contextMenus.create({
    id: 'scan-page',
    title: 'Scan this page for deals',
    contexts: ['page']
  });
  
  console.log('[Background] Initialization complete');
});

// Load and watch settings
async function loadSettings() {
  const data = await chrome.storage.local.get(['settings']);
  
  if (data.settings) {
    settings = data.settings;
  } else {
    // First run - set defaults
    settings = {
      version: '3.2.0',
      automation: {
        enabled: false,
        scanInterval: 30,
        maxConcurrentTabs: 3,
        pauseDuringActive: true
      },
      notifications: {
        enabled: true,
        desktop: true,
        sound: false
      }
    };
    await chrome.storage.local.set({ settings });
  }
  
  // Apply settings
  applySettings();
}

// Apply settings changes
function applySettings() {
  console.log('[Background] Applying settings:', settings);
  
  // Update automation
  if (settings.automation?.enabled) {
    setupAutomation();
  } else {
    disableAutomation();
  }
}

// Setup automation based on settings
async function setupAutomation() {
  const interval = settings.automation.scanInterval || 30;
  
  console.log('[Background] Setting up automation, interval:', interval, 'minutes');
  
  // Clear existing alarm
  if (automationAlarm) {
    await chrome.alarms.clear('auto-scan');
  }
  
  // Create new alarm
  chrome.alarms.create('auto-scan', {
    delayInMinutes: 1, // Start soon
    periodInMinutes: interval
  });
  
  automationAlarm = true;
}

// Disable automation
async function disableAutomation() {
  console.log('[Background] Disabling automation');
  
  if (automationAlarm) {
    await chrome.alarms.clear('auto-scan');
    automationAlarm = null;
  }
}

// Handle alarms
chrome.alarms.onAlarm.addListener(async (alarm) => {
  console.log('[Background] Alarm fired:', alarm.name);
  
  if (alarm.name === 'auto-scan' && settings.automation?.enabled) {
    // Check if we should pause
    if (settings.automation.pauseDuringActive) {
      const state = await chrome.idle.queryState(60); // 1 minute idle threshold
      if (state === 'active') {
        console.log('[Background] User active, skipping scan');
        return;
      }
    }
    
    // Run auto scan
    await runAutoScan();
  }
});

// Run automated scan
async function runAutoScan() {
  console.log('[Background] Starting auto scan');
  
  const savedSearches = settings.search?.savedSearches || [];
  const enabledSearches = savedSearches.filter(s => s.enabled);
  
  if (enabledSearches.length === 0) {
    console.log('[Background] No enabled searches');
    return;
  }
  
  const maxTabs = settings.automation.maxConcurrentTabs || 3;
  
  // Process searches in batches
  for (let i = 0; i < enabledSearches.length; i += maxTabs) {
    const batch = enabledSearches.slice(i, i + maxTabs);
    
    await Promise.all(batch.map(async (search) => {
      try {
        // Create tab
        const tab = await chrome.tabs.create({
          url: search.url,
          active: false
        });
        
        // Wait for load
        await new Promise(resolve => {
          chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
            if (tabId === tab.id && info.status === 'complete') {
              chrome.tabs.onUpdated.removeListener(listener);
              resolve();
            }
          });
        });
        
        // Inject scanner
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['js/scanner.js']
        });
        
        // Start scan
        chrome.tabs.sendMessage(tab.id, { action: 'START_SCAN' });
        
        // Close tab after delay
        setTimeout(() => {
          chrome.tabs.remove(tab.id);
        }, 10000); // 10 seconds to scan
        
      } catch (error) {
        console.error('[Background] Auto scan error:', error);
      }
    }));
    
    // Delay between batches
    if (i + maxTabs < enabledSearches.length) {
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
  }
  
  // Show notification
  if (settings.notifications?.enabled && settings.notifications?.triggers?.autoScanComplete) {
    showNotification('Auto Scan Complete', `Scanned ${enabledSearches.length} searches`);
  }
}

// Handle messages
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('[Background] Message received:', request.action);
  
  switch (request.action) {
    case 'OPEN_DASHBOARD':
      chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') });
      break;
      
    case 'SCAN_CURRENT_TAB':
      handleScanCurrentTab();
      break;
      
    case 'GET_VERSION':
      sendResponse({ version: chrome.runtime.getManifest().version });
      break;
      
    case 'STORE_SCAN_RESULTS':
      handleStoreScanResults(request.data).then(sendResponse);
      return true;
      
    case 'SETTINGS_UPDATED':
      // Reload settings and apply
      settings = request.data;
      applySettings();
      break;
      
    default:
      console.warn('[Background] Unknown action:', request.action);
  }
});

// Context menu handler
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'scan-page' && tab?.id) {
    injectScanner(tab.id);
  }
});

// Scan current tab
async function handleScanCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.id) {
    await injectScanner(tab.id);
  }
}

// Inject scanner
async function injectScanner(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['js/scanner.js']
    });
    
    chrome.tabs.sendMessage(tabId, { action: 'START_SCAN' });
  } catch (error) {
    console.error('[Background] Failed to inject scanner:', error);
    showNotification('Scan Failed', 'Unable to scan this page', 'error');
  }
}

// Store scan results
async function handleStoreScanResults(data) {
  try {
    const { listings = [] } = await chrome.storage.local.get(['listings']);
    
    // Deduplicate
    const existingIds = new Set(listings.map(l => l.id));
    const newListings = data.listings.filter(l => !existingIds.has(l.id));
    
    if (newListings.length > 0) {
      // Calculate if any are good deals based on settings
      const goodDeals = newListings.filter(listing => {
        const roi = calculateROI(listing);
        return roi >= (settings.search?.defaultFilters?.minROI || 20);
      });
      
      const updated = [...newListings, ...listings].slice(0, 1000);
      await chrome.storage.local.set({ listings: updated });
      
      // Show notification
      if (settings.notifications?.enabled && settings.notifications?.triggers?.newDeal && goodDeals.length > 0) {
        showNotification(
          'New Deals Found!', 
          `Found ${goodDeals.length} profitable deals`,
          'success'
        );
      }
    }
    
    return { success: true, newCount: newListings.length };
  } catch (error) {
    console.error('[Background] Failed to store results:', error);
    return { success: false, error: String(error) };
  }
}

// Calculate ROI for a listing
function calculateROI(listing) {
  // Simple calculation - would be more complex in reality
  const estimatedValue = listing.price * 1.5; // Assume 50% markup potential
  const costs = listing.price * 1.1; // Add 10% for fees/shipping
  const profit = estimatedValue - costs;
  return (profit / costs) * 100;
}

// Show notification
function showNotification(title, message, type = 'info') {
  if (!settings.notifications?.enabled || !settings.notifications?.desktop) {
    return;
  }
  
  // Check quiet hours
  if (settings.notifications?.quietHours?.enabled) {
    const now = new Date();
    const currentTime = now.getHours() * 60 + now.getMinutes();
    
    const [startHour, startMin] = settings.notifications.quietHours.start.split(':').map(Number);
    const [endHour, endMin] = settings.notifications.quietHours.end.split(':').map(Number);
    
    const startTime = startHour * 60 + startMin;
    const endTime = endHour * 60 + endMin;
    
    // Handle overnight quiet hours
    if (startTime > endTime) {
      if (currentTime >= startTime || currentTime <= endTime) {
        console.log('[Background] In quiet hours, skipping notification');
        return;
      }
    } else {
      if (currentTime >= startTime && currentTime <= endTime) {
        console.log('[Background] In quiet hours, skipping notification');
        return;
      }
    }
  }
  
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon-48.png',
    title,
    message,
    priority: type === 'error' ? 2 : 1
  });
  
  // Play sound if enabled
  if (settings.notifications?.sound) {
    // Would play sound here
    console.log('[Background] Would play notification sound');
  }
}

// Keep service worker alive
setInterval(() => {
  chrome.storage.local.get(['ping'], () => {
    // Just accessing storage keeps the service worker alive
  });
}, 20000);

// Listen for storage changes
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.settings) {
    console.log('[Background] Settings changed externally');
    settings = changes.settings.newValue;
    applySettings();
  }
});

console.log('[Background] Service worker initialized v3.2.0');