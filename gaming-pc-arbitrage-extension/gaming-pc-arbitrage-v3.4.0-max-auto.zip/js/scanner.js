// Scanner v3.4.0 - Enhanced with job support
console.log('[Scanner] Injected v3.4.0');

// Scanner class for better organization
class MarketplaceScanner {
  constructor(jobId) {
    this.jobId = jobId;
    this.listings = [];
    this.platform = this.detectPlatform();
  }
  
  detectPlatform() {
    const hostname = window.location.hostname;
    if (hostname.includes('facebook.com')) return 'facebook';
    if (hostname.includes('craigslist.org')) return 'craigslist';
    if (hostname.includes('offerup.com')) return 'offerup';
    return 'unknown';
  }
  
  async scan() {
    console.log(`[Scanner] Scanning ${this.platform} page...`);
    
    try {
      switch (this.platform) {
        case 'facebook':
          await this.scanFacebook();
          break;
        case 'craigslist':
          await this.scanCraigslist();
          break;
        case 'offerup':
          await this.scanOfferUp();
          break;
        default:
          throw new Error('Unsupported platform');
      }
      
      // Process and send results
      await this.processResults();
      
    } catch (error) {
      console.error('[Scanner] Error:', error);
      this.sendError(error.message);
    }
  }
  
  async scanFacebook() {
    // Wait a bit for dynamic content
    await this.waitForContent('[data-testid*="marketplace"]', 5000);
    
    // Try multiple selectors
    const selectors = [
      '[data-testid="marketplace-feed-item"]',
      '[data-testid="marketplace-search-feed-item"]',
      'div[role="article"]',
      'a[href*="/marketplace/item/"]'
    ];
    
    let elements = [];
    for (const selector of selectors) {
      elements = document.querySelectorAll(selector);
      if (elements.length > 0) {
        console.log(`[Scanner] Found ${elements.length} items with selector: ${selector}`);
        break;
      }
    }
    
    elements.forEach((el, index) => {
      try {
        // Extract title - try multiple selectors
        let title = '';
        const titleSelectors = [
          'span[class*="title"]',
          'span[dir="auto"]',
          '[role="heading"]',
          'h3'
        ];
        
        for (const sel of titleSelectors) {
          const titleEl = el.querySelector(sel);
          if (titleEl && titleEl.textContent) {
            title = titleEl.textContent.trim();
            break;
          }
        }
        
        // Extract price
        let price = 0;
        const priceText = el.textContent.match(/\$[\d,]+/) || el.textContent.match(/[\d,]+/);
        if (priceText) {
          price = parseInt(priceText[0].replace(/[^0-9]/g, '')) || 0;
        }
        
        // Extract URL
        let url = '';
        const linkEl = el.querySelector('a[href*="/marketplace/item/"]') || el.closest('a');
        if (linkEl) {
          url = linkEl.href;
        }
        
        // Check if it's a gaming PC
        if (this.isGamingPC(title) && price > 0) {
          this.listings.push({
            id: `fb_${Date.now()}_${index}`,
            title: title.substring(0, 200),
            price,
            platform: 'facebook',
            url: url || window.location.href,
            location: this.extractLocation(el),
            foundAt: new Date().toISOString(),
            image: this.extractImage(el)
          });
        }
      } catch (err) {
        console.warn('[Scanner] Error parsing item:', err);
      }
    });
    
    console.log(`[Scanner] Found ${this.listings.length} gaming PCs on Facebook`);
  }
  
  async scanCraigslist() {
    // Wait for content
    await this.waitForContent('.result-row', 3000);
    
    document.querySelectorAll('.result-row').forEach((row, index) => {
      const titleEl = row.querySelector('.result-title');
      const priceEl = row.querySelector('.result-price');
      
      if (titleEl && priceEl) {
        const title = titleEl.textContent.trim();
        const priceText = priceEl.textContent;
        const price = parseInt(priceText.replace(/[^0-9]/g, '')) || 0;
        
        if (this.isGamingPC(title) && price > 0) {
          this.listings.push({
            id: `cl_${Date.now()}_${index}`,
            title: title.substring(0, 200),
            price,
            platform: 'craigslist',
            url: titleEl.href || window.location.href,
            location: row.querySelector('.result-hood')?.textContent?.trim() || '',
            foundAt: new Date().toISOString()
          });
        }
      }
    });
    
    console.log(`[Scanner] Found ${this.listings.length} gaming PCs on Craigslist`);
  }
  
  async scanOfferUp() {
    // Wait for content
    await this.waitForContent('a[href*="/item/detail/"]', 5000);
    
    document.querySelectorAll('a[href*="/item/detail/"]').forEach((item, index) => {
      const titleEl = item.querySelector('p[class*="title"], span[class*="title"]');
      const priceEl = item.querySelector('span[class*="price"]');
      
      if (titleEl && priceEl) {
        const title = titleEl.textContent.trim();
        const priceText = priceEl.textContent;
        const price = parseInt(priceText.replace(/[^0-9]/g, '')) || 0;
        
        if (this.isGamingPC(title) && price > 0) {
          this.listings.push({
            id: `ou_${Date.now()}_${index}`,
            title: title.substring(0, 200),
            price,
            platform: 'offerup',
            url: item.href,
            foundAt: new Date().toISOString()
          });
        }
      }
    });
    
    console.log(`[Scanner] Found ${this.listings.length} gaming PCs on OfferUp`);
  }
  
  isGamingPC(title) {
    if (!title) return false;
    
    const lower = title.toLowerCase();
    
    // Must have PC-related terms
    const pcTerms = ['pc', 'computer', 'desktop', 'tower', 'rig', 'build', 'system'];
    const hasPCTerm = pcTerms.some(term => lower.includes(term));
    
    // Must have gaming or performance indicators
    const gamingTerms = [
      'gaming', 'gamer', 'game', 'gtx', 'rtx', 'radeon', 'rx', 'nvidia', 'amd',
      'intel', 'i5', 'i7', 'i9', 'ryzen', 'rgb', 'fps', 'gpu', 'graphics'
    ];
    const hasGamingTerm = gamingTerms.some(term => lower.includes(term));
    
    // Exclude unwanted items
    const excludeTerms = ['laptop', 'notebook', 'macbook', 'parts only', 'broken', 'repair'];
    const hasExcludeTerm = excludeTerms.some(term => lower.includes(term));
    
    return (hasPCTerm || hasGamingTerm) && !hasExcludeTerm;
  }
  
  extractLocation(element) {
    // Try to find location text
    const locationSelectors = [
      '[class*="location"]',
      '[class*="distance"]',
      'span[dir="auto"]'
    ];
    
    for (const sel of locationSelectors) {
      const locEl = element.querySelector(sel);
      if (locEl && locEl.textContent) {
        const text = locEl.textContent.trim();
        if (text.includes('mi') || text.includes('mile') || text.includes('km')) {
          return text;
        }
      }
    }
    
    return '';
  }
  
  extractImage(element) {
    const img = element.querySelector('img');
    return img ? img.src : '';
  }
  
  async waitForContent(selector, timeout = 5000) {
    const start = Date.now();
    
    while (Date.now() - start < timeout) {
      const elements = document.querySelectorAll(selector);
      if (elements.length > 0) {
        return elements;
      }
      await new Promise(resolve => setTimeout(resolve, 200));
    }
    
    console.warn(`[Scanner] Timeout waiting for ${selector}`);
    return [];
  }
  
  async processResults() {
    // Send results to background
    const response = await chrome.runtime.sendMessage({
      action: 'STORE_SCAN_RESULTS',
      data: { listings: this.listings }
    });
    
    // Calculate good deals
    const settings = await this.getSettings();
    const minROI = settings?.search?.defaultFilters?.minROI || 20;
    
    const goodDeals = this.listings.filter(listing => {
      // Simple ROI calculation - would be more complex in reality
      const estimatedValue = listing.price * 1.5;
      const costs = listing.price * 1.1;
      const profit = estimatedValue - costs;
      const roi = (profit / costs) * 100;
      return roi >= minROI;
    });
    
    // Send completion message
    if (this.jobId) {
      chrome.runtime.sendMessage({
        action: 'SCAN_COMPLETE',
        jobId: this.jobId,
        results: {
          listings: this.listings,
          newCount: response?.newCount || 0,
          goodDeals: goodDeals.length
        }
      });
    }
    
    console.log(`[Scanner] Scan complete. Found ${this.listings.length} listings, ${goodDeals.length} good deals`);
  }
  
  async getSettings() {
    try {
      const { settings } = await chrome.storage.local.get(['settings']);
      return settings;
    } catch (e) {
      return null;
    }
  }
  
  sendError(error) {
    if (this.jobId) {
      chrome.runtime.sendMessage({
        action: 'SCAN_FAILED',
        jobId: this.jobId,
        error
      });
    }
  }
}

// Listen for messages
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'START_SCAN') {
    console.log('[Scanner] Received scan request');
    const scanner = new MarketplaceScanner(request.jobId);
    scanner.scan();
  }
});