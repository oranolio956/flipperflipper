// Settings Manager v3.2.0 - Production Implementation
// Handles all settings persistence and state management

class SettingsManager {
  constructor() {
    this.settings = null;
    this.listeners = new Set();
    this.saveTimer = null;
    this.initialized = false;
    
    // Default settings structure
    this.defaults = {
      version: '3.2.0',
      
      automation: {
        enabled: false,
        scanInterval: 30, // minutes
        maxConcurrentTabs: 3,
        pauseDuringActive: true,
        retryAttempts: 3,
        retryDelay: 5 // seconds
      },
      
      search: {
        savedSearches: [],
        defaultFilters: {
          minPrice: 100,
          maxPrice: 2000,
          minROI: 20,
          maxDistance: 25
        }
      },
      
      pricing: {
        defaultMarkup: 25, // percentage
        includeShipping: true,
        includeFees: true,
        marketplaceFees: {
          facebook: 5,
          craigslist: 0,
          offerup: 9.9
        },
        pricingStrategy: 'moderate' // aggressive, moderate, conservative
      },
      
      notifications: {
        enabled: true,
        sound: false,
        desktop: true,
        triggers: {
          newDeal: true,
          priceChange: true,
          autoScanComplete: false,
          errors: true
        },
        quietHours: {
          enabled: false,
          start: '22:00',
          end: '08:00'
        }
      },
      
      display: {
        theme: 'auto', // light, dark, auto
        compactMode: false,
        showAdvancedFeatures: false,
        defaultView: 'dashboard'
      },
      
      privacy: {
        analytics: true,
        crashReports: true,
        shareUsageData: false,
        dataRetention: 90, // days
        autoBackup: true
      },
      
      performance: {
        enablePrefetch: true,
        cacheLifetime: 30, // minutes
        maxStorageSize: 100, // MB
        throttleRequests: true
      },
      
      developer: {
        enabled: false,
        debugMode: false,
        logLevel: 'warn', // error, warn, info, debug
        showPerformanceMetrics: false
      }
    };
    
    this.init();
  }
  
  async init() {
    if (this.initialized) return;
    
    try {
      // Load settings from storage
      await this.load();
      
      // Listen for storage changes
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local' && changes.settings) {
          console.log('[Settings] External change detected');
          this.settings = changes.settings.newValue || this.defaults;
          this.notifyListeners();
        }
      });
      
      this.initialized = true;
      console.log('[Settings] Manager initialized');
    } catch (error) {
      console.error('[Settings] Initialization failed:', error);
    }
  }
  
  async load() {
    try {
      const data = await chrome.storage.local.get(['settings']);
      
      if (data.settings) {
        // Merge with defaults to handle new properties
        this.settings = this.deepMerge(this.defaults, data.settings);
        // Always update version
        this.settings.version = this.defaults.version;
      } else {
        // First run - use defaults
        this.settings = JSON.parse(JSON.stringify(this.defaults));
        await this.save(true);
      }
      
      console.log('[Settings] Loaded:', this.settings);
      return this.settings;
    } catch (error) {
      console.error('[Settings] Load failed:', error);
      this.settings = JSON.parse(JSON.stringify(this.defaults));
      return this.settings;
    }
  }
  
  async save(immediate = false) {
    if (!immediate && this.saveTimer) {
      clearTimeout(this.saveTimer);
    }
    
    const doSave = async () => {
      try {
        await chrome.storage.local.set({ settings: this.settings });
        console.log('[Settings] Saved successfully');
        
        // Notify background script
        try {
          await chrome.runtime.sendMessage({
            action: 'SETTINGS_UPDATED',
            data: this.settings
          });
        } catch (e) {
          // Background might not be ready
          console.warn('[Settings] Could not notify background:', e);
        }
      } catch (error) {
        console.error('[Settings] Save failed:', error);
        throw error;
      }
    };
    
    if (immediate) {
      await doSave();
    } else {
      // Debounce saves
      this.saveTimer = setTimeout(() => {
        doSave();
        this.saveTimer = null;
      }, 500);
    }
  }
  
  get() {
    if (!this.settings) {
      console.warn('[Settings] Not initialized, returning defaults');
      return JSON.parse(JSON.stringify(this.defaults));
    }
    return JSON.parse(JSON.stringify(this.settings));
  }
  
  async update(updates) {
    if (!this.settings) {
      await this.load();
    }
    
    this.settings = this.deepMerge(this.settings, updates);
    this.notifyListeners();
    await this.save();
  }
  
  async updatePath(path, value) {
    if (!this.settings) {
      await this.load();
    }
    
    // Navigate to nested property
    const keys = path.split('.');
    let current = this.settings;
    
    for (let i = 0; i < keys.length - 1; i++) {
      if (!current[keys[i]]) {
        current[keys[i]] = {};
      }
      current = current[keys[i]];
    }
    
    current[keys[keys.length - 1]] = value;
    
    this.notifyListeners();
    await this.save();
  }
  
  async reset(section) {
    if (section) {
      // Reset specific section
      this.settings[section] = JSON.parse(JSON.stringify(this.defaults[section]));
    } else {
      // Reset all
      this.settings = JSON.parse(JSON.stringify(this.defaults));
    }
    
    this.notifyListeners();
    await this.save(true);
  }
  
  subscribe(listener) {
    this.listeners.add(listener);
    // Immediately call with current settings
    listener(this.get());
    
    // Return unsubscribe function
    return () => {
      this.listeners.delete(listener);
    };
  }
  
  notifyListeners() {
    const current = this.get();
    this.listeners.forEach(listener => {
      try {
        listener(current);
      } catch (error) {
        console.error('[Settings] Listener error:', error);
      }
    });
  }
  
  // Helper methods
  
  async enableAutomation(enabled) {
    await this.updatePath('automation.enabled', enabled);
  }
  
  async addSavedSearch(search) {
    const newSearch = {
      ...search,
      id: `search_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    };
    
    const searches = [...this.settings.search.savedSearches, newSearch];
    await this.updatePath('search.savedSearches', searches);
    
    return newSearch.id;
  }
  
  async removeSavedSearch(id) {
    const searches = this.settings.search.savedSearches.filter(s => s.id !== id);
    await this.updatePath('search.savedSearches', searches);
  }
  
  async updateSavedSearch(id, updates) {
    const searches = this.settings.search.savedSearches.map(search =>
      search.id === id ? { ...search, ...updates } : search
    );
    await this.updatePath('search.savedSearches', searches);
  }
  
  getSavedSearches() {
    return this.settings?.search?.savedSearches || [];
  }
  
  isAutomationEnabled() {
    return this.settings?.automation?.enabled || false;
  }
  
  getAutomationSettings() {
    return this.settings?.automation || this.defaults.automation;
  }
  
  // Export/Import
  
  async export() {
    const data = {
      settings: this.settings,
      exportDate: new Date().toISOString(),
      version: chrome.runtime.getManifest().version
    };
    
    return JSON.stringify(data, null, 2);
  }
  
  async import(jsonData) {
    try {
      const data = JSON.parse(jsonData);
      
      if (!data.settings) {
        throw new Error('Invalid settings file');
      }
      
      // Merge with defaults
      this.settings = this.deepMerge(this.defaults, data.settings);
      this.settings.version = this.defaults.version;
      
      this.notifyListeners();
      await this.save(true);
      
      return true;
    } catch (error) {
      console.error('[Settings] Import failed:', error);
      throw new Error('Invalid settings file format');
    }
  }
  
  // Utility: Deep merge objects
  deepMerge(target, source) {
    const result = JSON.parse(JSON.stringify(target));
    
    const merge = (dst, src) => {
      for (const key in src) {
        if (src[key] && typeof src[key] === 'object' && !Array.isArray(src[key])) {
          dst[key] = dst[key] || {};
          merge(dst[key], src[key]);
        } else {
          dst[key] = src[key];
        }
      }
    };
    
    merge(result, source);
    return result;
  }
}

// Create singleton instance
window.settingsManager = new SettingsManager();