// Production Router v3.2.0 - No dependencies, pure JavaScript
// Apple-level performance with 60fps transitions

class Router {
  constructor() {
    this.routes = new Map();
    this.currentPath = '/';
    this.listeners = new Set();
    this.params = {};
    this.previousPath = null;
    
    // Performance optimization: debounce route changes
    this._navigateDebounced = this.debounce(this._navigate.bind(this), 16); // 60fps
    
    // Initialize
    if (typeof window !== 'undefined') {
      window.addEventListener('hashchange', this.handleHashChange.bind(this));
      window.addEventListener('popstate', this.handlePopState.bind(this));
      this.currentPath = this.getHashPath();
    }
  }
  
  debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }
  
  handleHashChange() {
    const newPath = this.getHashPath();
    if (newPath !== this.currentPath) {
      this._navigate(newPath);
    }
  }
  
  handlePopState() {
    this._navigate(this.getHashPath());
  }
  
  getHashPath() {
    if (typeof window === 'undefined') return '/';
    const hash = window.location.hash.slice(1);
    return hash || '/';
  }
  
  register(pattern, route) {
    this.routes.set(pattern, route);
  }
  
  navigate(path, options = {}) {
    const { replace = false, state = null } = options;
    
    if (typeof window !== 'undefined') {
      if (replace) {
        window.history.replaceState(state, '', `#${path}`);
      } else {
        window.history.pushState(state, '', `#${path}`);
      }
    }
    
    this._navigateDebounced(path);
  }
  
  _navigate(path) {
    this.previousPath = this.currentPath;
    this.currentPath = path;
    this.params = this.extractParams(path);
    
    // Notify listeners with transition info
    this.listeners.forEach(listener => {
      listener({
        path,
        params: this.params,
        previousPath: this.previousPath,
        transition: this.previousPath ? 'forward' : 'initial'
      });
    });
  }
  
  back() {
    if (typeof window !== 'undefined') {
      window.history.back();
    }
  }
  
  forward() {
    if (typeof window !== 'undefined') {
      window.history.forward();
    }
  }
  
  getCurrentPath() {
    return this.currentPath;
  }
  
  getParams() {
    return { ...this.params };
  }
  
  subscribe(listener) {
    this.listeners.add(listener);
    // Immediately call with current state
    listener({
      path: this.currentPath,
      params: this.params,
      previousPath: this.previousPath,
      transition: 'initial'
    });
    
    return () => this.listeners.delete(listener);
  }
  
  extractParams(actualPath) {
    const params = {};
    
    for (const [pattern, _] of this.routes) {
      const regex = this.patternToRegex(pattern);
      const match = actualPath.match(regex);
      
      if (match) {
        const paramNames = (pattern.match(/:(\w+)/g) || []).map(p => p.slice(1));
        paramNames.forEach((name, index) => {
          params[name] = decodeURIComponent(match[index + 1]);
        });
        break;
      }
    }
    
    return params;
  }
  
  patternToRegex(pattern) {
    const regexPattern = pattern
      .replace(/\//g, '\\/')
      .replace(/:(\w+)/g, '([^/]+)');
    return new RegExp(`^${regexPattern}$`);
  }
  
  getRoute(path) {
    // Exact match
    if (this.routes.has(path)) {
      return this.routes.get(path);
    }
    
    // Pattern match
    for (const [pattern, route] of this.routes) {
      const regex = this.patternToRegex(pattern);
      if (regex.test(path)) {
        return route;
      }
    }
    
    return null;
  }
  
  getAllRoutes() {
    return Array.from(this.routes.values());
  }
  
  // Prefetch route component
  async prefetch(path) {
    const route = this.getRoute(path);
    if (route && route.component && typeof route.component === 'function') {
      try {
        await route.component();
      } catch (e) {
        console.warn('Failed to prefetch route:', path, e);
      }
    }
  }
  
  destroy() {
    if (typeof window !== 'undefined') {
      window.removeEventListener('hashchange', this.handleHashChange);
      window.removeEventListener('popstate', this.handlePopState);
    }
    this.listeners.clear();
    this.routes.clear();
  }
}

// Create singleton
const router = new Router();

// Route definitions
const ROUTES = {
  dashboard: {
    path: '/',
    title: 'Dashboard',
    icon: 'dashboard',
    testId: 'route-dashboard'
  },
  scanner: {
    path: '/scanner',
    title: 'Scanner',
    icon: 'scan',
    testId: 'route-scanner'
  },
  pipeline: {
    path: '/pipeline',
    title: 'Pipeline',
    icon: 'pipeline',
    testId: 'route-pipeline'
  },
  settings: {
    path: '/settings',
    title: 'Settings',
    icon: 'settings',
    testId: 'route-settings'
  },
  automation: {
    path: '/automation',
    title: 'Automation',
    icon: 'automation',
    testId: 'route-automation'
  },
  inventory: {
    path: '/inventory',
    title: 'Inventory',
    icon: 'inventory',
    testId: 'route-inventory'
  },
  routes: {
    path: '/routes',
    title: 'Routes',
    icon: 'map',
    testId: 'route-routes'
  },
  finance: {
    path: '/finance',
    title: 'Finance',
    icon: 'finance',
    testId: 'route-finance'
  },
  comps: {
    path: '/comps',
    title: 'Comps',
    icon: 'chart',
    testId: 'route-comps'
  },
  analytics: {
    path: '/analytics',
    title: 'Analytics',
    icon: 'analytics',
    testId: 'route-analytics'
  },
  experiments: {
    path: '/experiments',
    title: 'Experiments',
    icon: 'experiment',
    testId: 'route-experiments'
  },
  team: {
    path: '/team',
    title: 'Team',
    icon: 'team',
    testId: 'route-team'
  },
  integrations: {
    path: '/integrations',
    title: 'Integrations',
    icon: 'integrations',
    testId: 'route-integrations'
  },
  help: {
    path: '/help',
    title: 'Help',
    icon: 'help',
    testId: 'route-help'
  },
  features: {
    path: '/features',
    title: 'Features',
    icon: 'features',
    testId: 'route-features'
  }
};

// Register all routes
Object.entries(ROUTES).forEach(([key, route]) => {
  router.register(route.path, { ...route, key });
});

// Navigation groups
const NAV_GROUPS = [
  {
    label: 'Core',
    routes: ['dashboard', 'scanner', 'pipeline']
  },
  {
    label: 'Operations',
    routes: ['inventory', 'routes', 'finance']
  },
  {
    label: 'Intelligence',
    routes: ['comps', 'analytics', 'experiments']
  },
  {
    label: 'System',
    routes: ['automation', 'team', 'settings', 'integrations']
  },
  {
    label: 'Support',
    routes: ['help', 'features']
  }
];

// Export for use
window.Router = router;
window.ROUTES = ROUTES;
window.NAV_GROUPS = NAV_GROUPS;