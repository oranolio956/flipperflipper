
// Content Script
console.log('PC Arbitrage content script loaded');

let overlayElement = null;

// Listen for messages
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'ANALYZE_NOW' || request.type === 'TRIGGER_ANALYSIS') {
    analyzeListing();
    sendResponse({ success: true });
  }
});

// Auto-analyze if on listing page
if (isListingPage()) {
  setTimeout(analyzeListing, 2000);
}

function isListingPage() {
  const url = window.location.href;
  return url.includes('/marketplace/item/') || 
         url.includes('/for-sale/') ||
         url.includes('/item/');
}

async function analyzeListing() {
  try {
    // Extract listing data
    const listing = extractListingData();
    
    // Send to background for analysis
    const response = await chrome.runtime.sendMessage({
      type: 'PARSE_LISTING',
      listing: listing
    });
    
    if (response.success) {
      showOverlay(response.listing);
    }
  } catch (error) {
    console.error('Analysis failed:', error);
  }
}

function extractListingData() {
  // Extract title
  const title = document.querySelector('h1')?.textContent || 
                document.querySelector('[data-testid="listing-title"]')?.textContent || 
                'Unknown Title';
  
  // Extract price
  const priceText = document.querySelector('[data-testid="price"]')?.textContent ||
                    document.querySelector('.price')?.textContent || '0';
  const price = parseInt(priceText.replace(/[^0-9]/g, '')) || 0;
  
  // Extract description
  const description = document.querySelector('[data-testid="description"]')?.textContent ||
                      document.querySelector('.description')?.textContent || '';
  
  return {
    title,
    price,
    description,
    url: window.location.href,
    platform: window.location.hostname
  };
}

function showOverlay(listing) {
  if (overlayElement) {
    overlayElement.remove();
  }
  
  overlayElement = document.createElement('div');
  overlayElement.className = 'arbitrage-overlay';
  overlayElement.innerHTML = `
    <div class="overlay-header">
      <h3>PC Arbitrage Analysis</h3>
      <button class="close-btn">×</button>
    </div>
    <div class="overlay-content">
      <div class="price-info">
        <span>Listed: $${listing.price}</span>
        <span>FMV: $${listing.fmv || listing.price}</span>
        <span>ROI: ${((listing.fmv - listing.price) / listing.price * 100).toFixed(1)}%</span>
      </div>
      <button class="save-deal-btn">Save Deal</button>
    </div>
  `;
  
  document.body.appendChild(overlayElement);
  
  // Event listeners
  overlayElement.querySelector('.close-btn').addEventListener('click', () => {
    overlayElement.remove();
  });
  
  overlayElement.querySelector('.save-deal-btn').addEventListener('click', async () => {
    await chrome.runtime.sendMessage({
      type: 'SAVE_DEAL',
      deal: listing
    });
  });
}
