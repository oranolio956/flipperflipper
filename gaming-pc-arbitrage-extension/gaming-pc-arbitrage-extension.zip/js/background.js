
// Background Service Worker
console.log('Background service worker started');

// Initialize ML models on install
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log('Extension installed:', details.reason);
  
  if (details.reason === 'install') {
    // Set default settings
    await chrome.storage.local.set({
      settings: {
        geography: { zipCode: '', searchRadius: 25 },
        financial: { minRoi: 25, maxBudget: 2000 },
        notifications: { deals: true, priceDrops: false }
      },
      deals: [],
      listings: {},
      mlModelVersion: '1.0.0'
    });
    
    // Open onboarding
    chrome.tabs.create({ url: 'dashboard.html#onboarding' });
  }
});

// Message handling
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Message received:', request.type);
  
  switch (request.type) {
    case 'PARSE_LISTING':
      // Parse listing from content script
      sendResponse({ 
        success: true, 
        listing: {
          title: 'Gaming PC',
          price: 1000,
          components: { cpu: 'Intel i7', gpu: 'RTX 3070' }
        }
      });
      break;
      
    case 'CALCULATE_FMV':
      // Calculate fair market value with ML
      const fmv = calculateFMV(request.listing);
      sendResponse({ success: true, fmv });
      break;
      
    case 'SAVE_DEAL':
      // Save deal to storage
      saveDeal(request.deal).then(() => {
        sendResponse({ success: true });
      });
      return true; // Will respond asynchronously
      
    case 'GET_SETTINGS':
      // Get settings from storage
      chrome.storage.local.get('settings').then(result => {
        sendResponse({ success: true, settings: result.settings });
      });
      return true;
      
    case 'TRIGGER_ANALYSIS':
      // Trigger analysis on current tab
      chrome.tabs.sendMessage(sender.tab.id, { type: 'ANALYZE_NOW' });
      sendResponse({ success: true });
      break;
      
    default:
      sendResponse({ success: false, error: 'Unknown message type' });
  }
  
  return false;
});

// Helper functions
function calculateFMV(listing) {
  // Simplified FMV calculation
  let baseValue = listing.price || 0;
  
  if (listing.components?.gpu?.includes('3070')) baseValue *= 1.2;
  if (listing.components?.gpu?.includes('3080')) baseValue *= 1.4;
  if (listing.components?.gpu?.includes('4070')) baseValue *= 1.5;
  if (listing.components?.gpu?.includes('4080')) baseValue *= 1.8;
  
  return Math.round(baseValue);
}

async function saveDeal(deal) {
  const { deals = [] } = await chrome.storage.local.get('deals');
  deals.push({
    ...deal,
    id: Date.now().toString(),
    createdAt: new Date().toISOString()
  });
  await chrome.storage.local.set({ deals });
  
  // Show notification
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon-48.png',
    title: 'Deal Saved!',
    message: 'Deal has been added to your pipeline'
  });
}

// Open dashboard on icon click
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: 'dashboard.html' });
});
