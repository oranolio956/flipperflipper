// Background Service Worker for Gaming PC Arbitrage Extension v2.0

console.log('Gaming PC Arbitrage Extension v2.0 - Background Service Started');

// Handle extension icon click
chrome.action.onClicked.addListener((tab) => {
  chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') });
});

// Handle alarms for Max Auto
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name.startsWith('search-scan-')) {
    console.log('Max Auto: Scanning saved search', alarm.name);
    // In production, this would open tabs and scan
  }
});

// Initialize on install
chrome.runtime.onInstalled.addListener(() => {
  console.log('Extension installed/updated');
  
  // Set default automation status
  chrome.storage.local.set({
    automationEnabled: true,
    dashboardStats: {
      revenue: { value: 12450, change: 12 },
      activeDeals: { value: 23, change: 5 },
      avgRoi: { value: 32, change: 3 },
      winRate: { value: 68, change: -2 }
    },
    recentCandidates: [
      {
        id: 'fb-123',
        title: 'RTX 3070 Gaming Build',
        platform: 'facebook',
        price: 800,
        estimatedProfit: 280,
        riskScore: 0.2,
        foundAt: new Date()
      },
      {
        id: 'cl-456',
        title: 'i7-10700K Custom PC',
        platform: 'craigslist',
        price: 950,
        estimatedProfit: 266,
        riskScore: 0.3,
        foundAt: new Date()
      }
    ]
  });
});

// Keep service worker alive
setInterval(() => {
  chrome.storage.local.get(['automationEnabled'], (result) => {
    if (result.automationEnabled) {
      console.log('Max Auto heartbeat - automation active');
    }
  });
}, 30000);