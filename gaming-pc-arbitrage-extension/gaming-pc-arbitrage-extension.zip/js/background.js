/**
 * Background Service Worker - Production Build
 * Gaming PC Arbitrage Extension v2.0.0
 */

// Core functionality
class MaxAutoEngine {
  constructor() {
    this.enabled = false;
    this.searches = [];
    this.scanQueue = [];
    this.init();
  }

  async init() {
    const result = await chrome.storage.local.get(['automationEnabled', 'savedSearches']);
    this.enabled = result.automationEnabled || false;
    this.searches = result.savedSearches || [];
    
    if (this.enabled) {
      this.setupAlarms();
    }
    
    chrome.alarms.onAlarm.addListener((alarm) => {
      if (alarm.name.startsWith('search-scan-')) {
        const searchId = alarm.name.replace('search-scan-', '');
        this.executeScan(searchId);
      }
    });
  }

  async enable() {
    this.enabled = true;
    await chrome.storage.local.set({ automationEnabled: true });
    this.setupAlarms();
  }

  async disable() {
    this.enabled = false;
    await chrome.storage.local.set({ automationEnabled: false });
    
    // Clear all alarms
    const alarms = await chrome.alarms.getAll();
    for (const alarm of alarms) {
      if (alarm.name.startsWith('search-scan-')) {
        await chrome.alarms.clear(alarm.name);
      }
    }
  }

  setupAlarms() {
    this.searches.forEach(search => {
      if (search.enabled) {
        chrome.alarms.create(`search-scan-${search.id}`, {
          periodInMinutes: search.cadenceMinutes
        });
      }
    });
  }

  async executeScan(searchId) {
    const search = this.searches.find(s => s.id === searchId);
    if (!search || !search.enabled) return;

    // Check if user is idle
    const idleState = await chrome.idle.queryState(60);
    if (idleState === 'active') {
      console.log('User is active, postponing scan');
      return;
    }

    // Create and pin tab
    const tab = await chrome.tabs.create({
      url: search.url,
      pinned: true,
      active: false
    });

    // Wait for page to load
    chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
      if (tabId === tab.id && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        
        // Inject content script and trigger scan
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['js/content-scanner.js']
        }, () => {
          setTimeout(() => {
            chrome.tabs.sendMessage(tab.id, {
              action: 'SCAN_PAGE',
              autoScan: true,
              searchId: search.id,
              scanId: `scan-${Date.now()}`
            }, (response) => {
              if (response && response.candidates && response.candidates.length > 0) {
                this.notifyHighValueFinds(response.candidates);
              }
              
              // Close tab after scan
              setTimeout(() => {
                chrome.tabs.remove(tab.id);
              }, 2000);
            });
          }, 3000);
        });
      }
    });
  }

  notifyHighValueFinds(candidates) {
    const highValue = candidates.filter(c => c.roi > 0.3);
    if (highValue.length > 0) {
      chrome.notifications.create({
        type: 'basic',
        iconUrl: '/icons/icon-128.png',
        title: 'High-Value Gaming PCs Found!',
        message: `Found ${highValue.length} listings with >30% potential ROI`,
        buttons: [{ title: 'View Dashboard' }],
        requireInteraction: true
      });
    }
  }
}

// Update checker
class UpdateChecker {
  constructor() {
    this.checkInterval = 24 * 60; // Daily
    this.init();
  }

  async init() {
    // Set up daily check
    chrome.alarms.create('update-check', {
      periodInMinutes: this.checkInterval
    });
    
    chrome.alarms.onAlarm.addListener((alarm) => {
      if (alarm.name === 'update-check') {
        this.checkForUpdates();
      }
    });
  }

  async checkForUpdates() {
    chrome.runtime.requestUpdateCheck((status, details) => {
      console.log('Update check:', status, details);
      
      if (status === 'update_available') {
        chrome.storage.local.set({
          updateStatus: 'available',
          updateDetails: details
        });
      } else {
        chrome.storage.local.set({
          updateStatus: 'current',
          lastUpdateCheck: new Date().toISOString()
        });
      }
    });
  }
}

// Initialize
const maxAutoEngine = new MaxAutoEngine();
const updateChecker = new UpdateChecker();

// Extension lifecycle
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log('Extension installed:', details.reason);
  
  if (details.reason === 'install') {
    // First install - open onboarding
    chrome.tabs.create({ url: 'dashboard.html#/help' });
  } else if (details.reason === 'update') {
    // Updated - check for migrations
    console.log(`Updated from v${details.previousVersion} to v${chrome.runtime.getManifest().version}`);
  }
});

// Message handling
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Background received:', request.action);

  // Scanner controls
  if (request.action === 'SCAN_PAGE') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, request, sendResponse);
      }
    });
    return true;
  }

  // Max Auto controls
  if (request.action === 'MAX_AUTO_ENABLE') {
    maxAutoEngine.enable().then(() => sendResponse({ success: true }));
    return true;
  }

  if (request.action === 'MAX_AUTO_DISABLE') {
    maxAutoEngine.disable().then(() => sendResponse({ success: true }));
    return true;
  }

  // Storage operations
  if (request.action === 'STORE_SCAN_RESULTS') {
    chrome.storage.local.get(['scannedListings'], (result) => {
      const existing = result.scannedListings || [];
      const merged = [...request.listings, ...existing].slice(0, 500);
      
      chrome.storage.local.set({
        scannedListings: merged,
        lastScanTime: new Date().toISOString()
      }, () => {
        sendResponse({ success: true });
      });
    });
    return true;
  }

  // Navigation
  if (request.action === 'openDashboard') {
    chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') });
    sendResponse({ success: true });
    return true;
  }

  if (request.action === 'openSettings') {
    chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html#/settings') });
    sendResponse({ success: true });
    return true;
  }

  // Update status
  if (request.action === 'GET_UPDATE_STATUS') {
    chrome.storage.local.get(['updateStatus', 'lastUpdateCheck'], (result) => {
      sendResponse({ 
        success: true, 
        status: {
          updateAvailable: result.updateStatus === 'available',
          lastCheck: result.lastUpdateCheck
        }
      });
    });
    return true;
  }

  return false;
});

// Context menu
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'scan-page',
    title: 'Scan for Gaming PCs',
    contexts: ['page'],
    documentUrlPatterns: [
      '*://*.facebook.com/*',
      '*://*.craigslist.org/*',
      '*://*.offerup.com/*'
    ]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'scan-page') {
    chrome.tabs.sendMessage(tab.id, { action: 'INJECT_SCANNER' });
  }
});

// Keep service worker alive
setInterval(() => {
  chrome.storage.local.get(['keepAlive'], () => {});
}, 20000);

console.log('Gaming PC Arbitrage Extension v2.0.0 - Background loaded');