
// Options Script
document.addEventListener('DOMContentLoaded', async () => {
  // Load settings
  const { settings = {} } = await chrome.storage.local.get('settings');
  
  document.getElementById('zip-code').value = settings.geography?.zipCode || '';
  document.getElementById('search-radius').value = settings.geography?.searchRadius || 25;
  
  // Save handler
  document.getElementById('save').addEventListener('click', async () => {
    const newSettings = {
      ...settings,
      geography: {
        zipCode: document.getElementById('zip-code').value,
        searchRadius: parseInt(document.getElementById('search-radius').value)
      }
    };
    
    await chrome.storage.local.set({ settings: newSettings });
    
    // Show saved message
    const btn = document.getElementById('save');
    btn.textContent = 'Saved!';
    setTimeout(() => { btn.textContent = 'Save Settings'; }, 2000);
  });
});
