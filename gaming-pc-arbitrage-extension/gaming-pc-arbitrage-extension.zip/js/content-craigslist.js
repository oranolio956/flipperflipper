/**
 * Facebook Marketplace Content Script - Production
 */

(function() {
  'use strict';

  // Parser functions
  function parseListingCard(element) {
    try {
      const linkEl = element.tagName === 'A' ? element : element.querySelector('a[href*="/marketplace/item/"]');
      if (!linkEl) return null;
      
      const url = linkEl.href;
      const itemId = url.match(/\/marketplace\/item\/(\d+)/)?.[1];
      if (!itemId) return null;
      
      // Extract title
      let title = '';
      const titleSelectors = ['span[dir="auto"]', '[role="heading"]', 'h3'];
      for (const selector of titleSelectors) {
        const el = element.querySelector(selector);
        if (el?.textContent) {
          title = el.textContent.trim();
          if (title.length > 5) break;
        }
      }
      
      if (!title) return null;
      
      // Extract price
      let price = 0;
      const priceText = findTextContent(element, /\$[\d,]+/);
      if (priceText) {
        price = parseInt(priceText.replace(/[^0-9]/g, '')) || 0;
      }
      
      // Extract location
      const location = findTextContent(element, /\d+\s*(mi|miles?|km)\s*(away)?/i) || 
                      findTextContent(element, /[A-Z][a-z]+,\s*[A-Z]{2}/);
      
      // Extract image
      const imgEl = element.querySelector('img[src*="scontent"]');
      const imageUrl = imgEl?.src;
      
      return {
        title,
        price,
        url,
        location,
        imageUrl,
        sellerId: itemId,
        postedDate: new Date().toISOString()
      };
      
    } catch (error) {
      console.error('[FB Parser] Error:', error);
      return null;
    }
  }
  
  function findTextContent(element, pattern) {
    const walker = document.createTreeWalker(
      element,
      NodeFilter.SHOW_TEXT,
      null
    );
    
    let node;
    while (node = walker.nextNode()) {
      const text = node.textContent?.trim();
      if (text && pattern.test(text)) {
        return text;
      }
    }
    
    return null;
  }

  // Scanner function
  async function performScan(request) {
    try {
      const listings = [];
      const startTime = performance.now();
      
      // Find listing elements
      const selectors = [
        '[data-testid="marketplace-feed-item"]',
        'div[role="article"] a[href*="/marketplace/item/"]',
        'div[class*="x1xfsgkm"] a[href*="/marketplace/item/"]',
        'a[href*="/marketplace/item/"][role="link"]'
      ];
      
      let elements = [];
      for (const selector of selectors) {
        const found = document.querySelectorAll(selector);
        if (found.length > 0) {
          elements = Array.from(found);
          console.log(`[FB Scanner] Found ${found.length} listings`);
          break;
        }
      }
      
      // Parse listings
      for (const element of elements) {
        const listing = parseListingCard(element);
        if (listing && listing.price > 0) {
          const text = (listing.title + ' ' + (listing.description || '')).toLowerCase();
          const gamingKeywords = ['gaming', 'pc', 'computer', 'desktop', 'rtx', 'gtx', 'radeon', 'ryzen', 'intel', 'i5', 'i7', 'i9'];
          
          if (gamingKeywords.some(kw => text.includes(kw))) {
            listings.push({
              ...listing,
              id: `fb-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
              platform: 'facebook',
              scannedAt: new Date().toISOString(),
              autoScanned: request.autoScan || false,
              searchId: request.searchId
            });
          }
        }
      }
      
      console.log(`[FB Scanner] Found ${listings.length} gaming PCs`);
      
      // Store results if auto-scan
      if (request.autoScan && listings.length > 0) {
        await chrome.runtime.sendMessage({
          action: 'STORE_SCAN_RESULTS',
          listings,
          searchId: request.searchId,
          scanId: request.scanId
        });
      }
      
      return {
        success: true,
        candidates: listings,
        scanTime: performance.now() - startTime,
        platform: 'facebook',
        totalScanned: elements.length
      };
      
    } catch (error) {
      console.error('[FB Scanner] Error:', error);
      return {
        success: false,
        error: error.message,
        platform: 'facebook'
      };
    }
  }

  // Scanner overlay
  function injectScanner() {
    if (document.getElementById('arbitrage-scanner-root')) return;
    
    const container = document.createElement('div');
    container.id = 'arbitrage-scanner-root';
    container.innerHTML = `
      <div id="scanner-widget" style="
        position: fixed;
        top: 20px;
        right: 20px;
        width: 360px;
        background: white;
        border-radius: 12px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.15);
        z-index: 999999;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      ">
        <div style="padding: 16px; border-bottom: 1px solid #e5e7eb;">
          <div style="display: flex; align-items: center; justify-content: space-between;">
            <h3 style="margin: 0; font-size: 16px; font-weight: 600; color: #111827;">
              PC Arbitrage Scanner
            </h3>
            <button id="scanner-close" style="
              background: none;
              border: none;
              padding: 4px;
              cursor: pointer;
              color: #6b7280;
              font-size: 20px;
              line-height: 1;
            ">×</button>
          </div>
        </div>
        
        <div style="padding: 16px;">
          <button id="scanner-scan-btn" style="
            width: 100%;
            padding: 12px;
            background: #3b82f6;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
          ">Scan This Page</button>
          
          <div id="scanner-status" style="
            margin-top: 12px;
            padding: 12px;
            background: #f3f4f6;
            border-radius: 6px;
            font-size: 13px;
            color: #4b5563;
            display: none;
          "></div>
          
          <div id="scanner-results" style="
            margin-top: 12px;
            max-height: 400px;
            overflow-y: auto;
          "></div>
        </div>
      </div>
    `;
    
    document.body.appendChild(container);
    
    // Wire up buttons
    document.getElementById('scanner-close').addEventListener('click', () => {
      container.remove();
    });
    
    document.getElementById('scanner-scan-btn').addEventListener('click', async () => {
      const btn = document.getElementById('scanner-scan-btn');
      const status = document.getElementById('scanner-status');
      const results = document.getElementById('scanner-results');
      
      btn.disabled = true;
      btn.textContent = 'Scanning...';
      status.style.display = 'block';
      status.textContent = 'Analyzing listings...';
      results.innerHTML = '';
      
      const response = await performScan({ autoScan: false });
      
      if (response.success) {
        status.innerHTML = `✓ Found ${response.candidates.length} gaming PCs`;
        
        if (response.candidates.length > 0) {
          results.innerHTML = response.candidates.map(listing => `
            <div style="
              padding: 12px;
              border: 1px solid #e5e7eb;
              border-radius: 6px;
              margin-bottom: 8px;
              cursor: pointer;
            " onclick="window.open('${listing.url}', '_blank')">
              <div style="font-weight: 500; margin-bottom: 4px;">${listing.title}</div>
              <div style="color: #059669; font-weight: 600;">$${listing.price.toLocaleString()}</div>
              ${listing.location ? `<div style="font-size: 12px; color: #6b7280;">📍 ${listing.location}</div>` : ''}
            </div>
          `).join('');
        }
      } else {
        status.innerHTML = '❌ Scan failed';
      }
      
      btn.disabled = false;
      btn.textContent = 'Scan This Page';
    });
  }

  // Message handling
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'PING') {
      sendResponse({ pong: true });
      return true;
    }

    if (request.action === 'SCAN_PAGE') {
      console.log('[FB Scanner] Scan requested');
      performScan(request).then(sendResponse);
      return true;
    }

    if (request.action === 'INJECT_SCANNER') {
      injectScanner();
      sendResponse({ success: true });
      return true;
    }
  });

  // Auto-inject on marketplace pages
  if (window.location.pathname.includes('/marketplace')) {
    console.log('[FB Scanner] Marketplace detected');
    setTimeout(() => injectScanner(), 2000);
  }

})();