
// Popup Script
document.addEventListener('DOMContentLoaded', async () => {
  // Load stats
  const { deals = [] } = await chrome.storage.local.get('deals');
  
  document.getElementById('active-deals').textContent = 
    deals.filter(d => d.stage !== 'sold').length;
  
  const totalProfit = deals
    .filter(d => d.stage === 'sold')
    .reduce((sum, d) => sum + (d.profit || 0), 0);
  document.getElementById('total-profit').textContent = '$' + totalProfit;
  
  // Load recent deals
  const recentDeals = deals.slice(-5).reverse();
  const dealsList = document.getElementById('deals-list');
  
  if (recentDeals.length === 0) {
    dealsList.innerHTML = '<p>No deals yet. Start analyzing!</p>';
  } else {
    dealsList.innerHTML = recentDeals.map(deal => `
      <div class="deal-item">
        <h4>${deal.title || 'Untitled'}</h4>
        <span>$${deal.price} - ${deal.stage || 'active'}</span>
      </div>
    `).join('');
  }
  
  // Button handlers
  document.getElementById('analyze-page').addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.tabs.sendMessage(tab.id, { type: 'TRIGGER_ANALYSIS' });
    window.close();
  });
  
  document.getElementById('open-dashboard').addEventListener('click', () => {
    chrome.tabs.create({ url: 'dashboard.html' });
    window.close();
  });
  
  document.getElementById('photo-capture').addEventListener('click', () => {
    chrome.tabs.create({ url: 'photo-capture.html' });
    window.close();
  });
  
  document.getElementById('bulk-scan').addEventListener('click', () => {
    chrome.tabs.create({ url: 'dashboard.html#bulk-scanner' });
    window.close();
  });
});
