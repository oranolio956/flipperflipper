/**
 * Popup Script - Production Build
 */

(function() {
  'use strict';

  // Initialize popup
  document.addEventListener('DOMContentLoaded', async () => {
    const root = document.getElementById('root');
    
    // Get current status
    const storage = await chrome.storage.local.get([
      'automationEnabled', 
      'scannedListings',
      'dashboardStats'
    ]);
    
    // Render popup UI
    root.innerHTML = `
      <div style="width: 400px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
        <div style="padding: 24px;">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px;">
            <h1 style="margin: 0; font-size: 20px; font-weight: 600; color: #111827;">
              PC Arbitrage
            </h1>
            <div style="display: flex; align-items: center; gap: 8px;">
              <span style="font-size: 12px; color: #6b7280;">Max Auto</span>
              <label style="position: relative; display: inline-block; width: 44px; height: 24px;">
                <input type="checkbox" id="automation-toggle" ${storage.automationEnabled ? 'checked' : ''} style="opacity: 0; width: 0; height: 0;">
                <span style="
                  position: absolute;
                  cursor: pointer;
                  top: 0;
                  left: 0;
                  right: 0;
                  bottom: 0;
                  background-color: ${storage.automationEnabled ? '#3b82f6' : '#e5e7eb'};
                  transition: .3s;
                  border-radius: 24px;
                ">
                  <span style="
                    position: absolute;
                    content: '';
                    height: 16px;
                    width: 16px;
                    left: ${storage.automationEnabled ? '24px' : '4px'};
                    bottom: 4px;
                    background-color: white;
                    transition: .3s;
                    border-radius: 50%;
                  "></span>
                </span>
              </label>
            </div>
          </div>
          
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 20px;">
            <div style="
              padding: 16px;
              background: #f0f9ff;
              border-radius: 8px;
              text-align: center;
            ">
              <div style="font-size: 24px; font-weight: 600; color: #1e40af; margin-bottom: 4px;">
                ${storage.scannedListings?.length || 0}
              </div>
              <div style="font-size: 12px; color: #64748b;">
                Listings Found
              </div>
            </div>
            
            <div style="
              padding: 16px;
              background: #f0fdf4;
              border-radius: 8px;
              text-align: center;
            ">
              <div style="font-size: 24px; font-weight: 600; color: #16a34a; margin-bottom: 4px;">
                ${storage.dashboardStats?.activeDeals?.value || 0}
              </div>
              <div style="font-size: 12px; color: #64748b;">
                Active Deals
              </div>
            </div>
          </div>
          
          <div style="margin-bottom: 20px;">
            <h3 style="font-size: 14px; font-weight: 500; color: #374151; margin-bottom: 12px;">
              Quick ROI Calculator
            </h3>
            <div style="display: grid; gap: 8px;">
              <input type="number" id="calc-price" placeholder="Asking Price" style="
                padding: 8px 12px;
                border: 1px solid #e5e7eb;
                border-radius: 6px;
                font-size: 14px;
              ">
              <input type="text" id="calc-specs" placeholder="e.g., RTX 3070, i5-11400" style="
                padding: 8px 12px;
                border: 1px solid #e5e7eb;
                border-radius: 6px;
                font-size: 14px;
              ">
              <button id="calc-btn" style="
                padding: 10px;
                background: #3b82f6;
                color: white;
                border: none;
                border-radius: 6px;
                font-size: 14px;
                font-weight: 500;
                cursor: pointer;
              ">Calculate ROI</button>
            </div>
            <div id="calc-result" style="
              margin-top: 8px;
              padding: 12px;
              background: #f9fafb;
              border-radius: 6px;
              font-size: 13px;
              display: none;
            "></div>
          </div>
          
          <div style="display: grid; gap: 8px;">
            <button id="scan-current" style="
              padding: 12px;
              background: #10b981;
              color: white;
              border: none;
              border-radius: 6px;
              font-size: 14px;
              font-weight: 500;
              cursor: pointer;
            ">Scan Current Page</button>
            
            <button id="open-dashboard" style="
              padding: 12px;
              background: #6366f1;
              color: white;
              border: none;
              border-radius: 6px;
              font-size: 14px;
              font-weight: 500;
              cursor: pointer;
            ">Open Dashboard</button>
            
            <button id="open-settings" style="
              padding: 12px;
              background: #f3f4f6;
              color: #374151;
              border: none;
              border-radius: 6px;
              font-size: 14px;
              font-weight: 500;
              cursor: pointer;
            ">Settings</button>
          </div>
        </div>
        
        <div style="
          padding: 12px 24px;
          background: #f9fafb;
          border-top: 1px solid #e5e7eb;
          font-size: 12px;
          color: #6b7280;
          text-align: center;
        ">
          v${chrome.runtime.getManifest().version} • 
          <a href="#" id="check-updates" style="color: #3b82f6; text-decoration: none;">Check for updates</a>
        </div>
      </div>
    `;
    
    // Wire up automation toggle
    document.getElementById('automation-toggle').addEventListener('change', async (e) => {
      const enabled = e.target.checked;
      await chrome.runtime.sendMessage({
        action: enabled ? 'MAX_AUTO_ENABLE' : 'MAX_AUTO_DISABLE'
      });
      
      // Update visual state
      const slider = e.target.nextElementSibling;
      slider.style.backgroundColor = enabled ? '#3b82f6' : '#e5e7eb';
      slider.firstElementChild.style.left = enabled ? '24px' : '4px';
    });
    
    // ROI Calculator
    document.getElementById('calc-btn').addEventListener('click', () => {
      const price = parseFloat(document.getElementById('calc-price').value);
      const specs = document.getElementById('calc-specs').value;
      const resultDiv = document.getElementById('calc-result');
      
      if (!price || !specs) {
        resultDiv.style.display = 'none';
        return;
      }
      
      // Simple ROI calculation based on keywords
      let estimatedValue = price;
      const specLower = specs.toLowerCase();
      
      // GPU values
      if (specLower.includes('4090')) estimatedValue = 1800;
      else if (specLower.includes('4080')) estimatedValue = 1200;
      else if (specLower.includes('4070')) estimatedValue = 600;
      else if (specLower.includes('3090')) estimatedValue = 900;
      else if (specLower.includes('3080')) estimatedValue = 700;
      else if (specLower.includes('3070')) estimatedValue = 500;
      else if (specLower.includes('3060')) estimatedValue = 350;
      
      // CPU adjustments
      if (specLower.includes('i9')) estimatedValue += 300;
      else if (specLower.includes('i7')) estimatedValue += 200;
      else if (specLower.includes('i5')) estimatedValue += 100;
      
      const profit = estimatedValue - price;
      const roi = (profit / price * 100).toFixed(1);
      
      resultDiv.style.display = 'block';
      resultDiv.innerHTML = `
        <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
          <span>Estimated Value:</span>
          <span style="font-weight: 500;">$${estimatedValue.toLocaleString()}</span>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
          <span>Potential Profit:</span>
          <span style="font-weight: 500; color: ${profit > 0 ? '#16a34a' : '#dc2626'};">
            $${profit.toLocaleString()}
          </span>
        </div>
        <div style="display: flex; justify-content: space-between;">
          <span>ROI:</span>
          <span style="font-weight: 600; color: ${profit > 0 ? '#16a34a' : '#dc2626'};">
            ${roi}%
          </span>
        </div>
      `;
    });
    
    // Button handlers
    document.getElementById('scan-current').addEventListener('click', async () => {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'INJECT_SCANNER' });
        window.close();
      }
    });
    
    document.getElementById('open-dashboard').addEventListener('click', () => {
      chrome.runtime.sendMessage({ action: 'openDashboard' });
      window.close();
    });
    
    document.getElementById('open-settings').addEventListener('click', () => {
      chrome.runtime.sendMessage({ action: 'openSettings' });
      window.close();
    });
    
    document.getElementById('check-updates').addEventListener('click', async (e) => {
      e.preventDefault();
      const response = await chrome.runtime.sendMessage({ action: 'CHECK_FOR_UPDATES' });
      alert('Update check complete. Check dashboard for status.');
    });
  });

})();