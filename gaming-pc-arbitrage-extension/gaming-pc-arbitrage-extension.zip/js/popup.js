/**
 * Popup Script - FULL VERSION 3.0
 * Shows ALL 100+ features
 */

(function() {
  'use strict';

  // Initialize popup
  document.addEventListener('DOMContentLoaded', async () => {
    const root = document.getElementById('root');
    
    // Get current status and features
    const storage = await chrome.storage.local.get([
      'automationEnabled', 
      'scannedListings',
      'dashboardStats',
      'savedSearches',
      'automationStats',
      'priceModel',
      'activeFeatures'
    ]);
    
    // Get feature status from background
    const featureStatus = await chrome.runtime.sendMessage({ action: 'GET_FEATURE_STATUS' });
    
    // Render enhanced popup UI
    root.innerHTML = `
      <div style="width: 480px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
        <!-- Header -->
        <div style="
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          padding: 24px;
          color: white;
        ">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px;">
            <div>
              <h1 style="margin: 0; font-size: 24px; font-weight: 700;">
                PC Arbitrage Pro
              </h1>
              <div style="font-size: 12px; opacity: 0.9; margin-top: 4px;">
                v3.0.0 • ${featureStatus?.features?.totalFeatures || 104} Features
              </div>
            </div>
            <div style="text-align: right;">
              <div style="font-size: 11px; opacity: 0.8;">Max Auto™</div>
              <label style="position: relative; display: inline-block; width: 50px; height: 26px;">
                <input type="checkbox" id="automation-toggle" ${storage.automationEnabled ? 'checked' : ''} style="opacity: 0; width: 0; height: 0;">
                <span style="
                  position: absolute;
                  cursor: pointer;
                  top: 0;
                  left: 0;
                  right: 0;
                  bottom: 0;
                  background-color: ${storage.automationEnabled ? '#48bb78' : '#cbd5e0'};
                  transition: .3s;
                  border-radius: 26px;
                  box-shadow: inset 0 2px 4px rgba(0,0,0,0.1);
                ">
                  <span style="
                    position: absolute;
                    content: '';
                    height: 20px;
                    width: 20px;
                    left: ${storage.automationEnabled ? '27px' : '3px'};
                    bottom: 3px;
                    background-color: white;
                    transition: .3s;
                    border-radius: 50%;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.2);
                  "></span>
                </span>
              </label>
            </div>
          </div>
          
          <!-- Live Stats -->
          <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px;">
            <div style="text-align: center;">
              <div style="font-size: 24px; font-weight: 700;">
                ${storage.scannedListings?.length || 0}
              </div>
              <div style="font-size: 11px; opacity: 0.9;">
                Listings Found
              </div>
            </div>
            <div style="text-align: center;">
              <div style="font-size: 24px; font-weight: 700;">
                ${storage.dashboardStats?.activeDeals?.value || 0}
              </div>
              <div style="font-size: 11px; opacity: 0.9;">
                Active Deals
              </div>
            </div>
            <div style="text-align: center;">
              <div style="font-size: 24px; font-weight: 700;">
                ${storage.automationStats?.totalScans || 0}
              </div>
              <div style="font-size: 11px; opacity: 0.9;">
                Auto Scans
              </div>
            </div>
          </div>
        </div>
        
        <div style="padding: 20px;">
          <!-- Active Features Indicator -->
          <div style="
            background: #f7fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            justify-content: space-between;
          ">
            <div style="display: flex; align-items: center; gap: 8px;">
              <div style="
                width: 8px;
                height: 8px;
                background: #48bb78;
                border-radius: 50%;
                animation: pulse 2s infinite;
              "></div>
              <span style="font-size: 13px; color: #2d3748;">
                ${featureStatus?.features?.activeFeatures || 90} Features Active
              </span>
            </div>
            <button id="view-features" style="
              font-size: 11px;
              color: #667eea;
              background: none;
              border: none;
              cursor: pointer;
              text-decoration: underline;
            ">View All</button>
          </div>
          
          <!-- Quick ROI Calculator -->
          <div style="margin-bottom: 20px;">
            <h3 style="font-size: 14px; font-weight: 600; color: #2d3748; margin-bottom: 12px; display: flex; align-items: center; gap: 6px;">
              <span>⚡</span> Quick Analysis
            </h3>
            <div style="display: grid; gap: 8px;">
              <div style="position: relative;">
                <input type="number" id="calc-price" placeholder="Asking Price" style="
                  width: 100%;
                  padding: 10px 12px;
                  border: 1px solid #e2e8f0;
                  border-radius: 6px;
                  font-size: 14px;
                  transition: border-color 0.2s;
                ">
              </div>
              <div style="position: relative;">
                <input type="text" id="calc-specs" placeholder="e.g., RTX 3070, i5-11400, 16GB RAM" style="
                  width: 100%;
                  padding: 10px 12px;
                  border: 1px solid #e2e8f0;
                  border-radius: 6px;
                  font-size: 14px;
                ">
              </div>
              <button id="calc-btn" style="
                padding: 12px;
                background: #667eea;
                color: white;
                border: none;
                border-radius: 6px;
                font-size: 14px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.2s;
              ">Calculate ROI & Risk</button>
            </div>
            <div id="calc-result" style="
              margin-top: 12px;
              padding: 12px;
              background: #f7fafc;
              border-radius: 6px;
              font-size: 13px;
              display: none;
            "></div>
          </div>
          
          <!-- Smart Actions -->
          <div style="margin-bottom: 20px;">
            <h3 style="font-size: 14px; font-weight: 600; color: #2d3748; margin-bottom: 12px; display: flex; align-items: center; gap: 6px;">
              <span>🚀</span> Smart Actions
            </h3>
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px;">
              <button id="scan-current" class="action-button" style="
                padding: 14px;
                background: #48bb78;
                color: white;
                border: none;
                border-radius: 6px;
                font-size: 13px;
                font-weight: 600;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 6px;
                transition: all 0.2s;
              ">
                <span>🔍</span> Scan This Page
              </button>
              
              <button id="bulk-analyze" class="action-button" style="
                padding: 14px;
                background: #4299e1;
                color: white;
                border: none;
                border-radius: 6px;
                font-size: 13px;
                font-weight: 600;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 6px;
                transition: all 0.2s;
              ">
                <span>📊</span> Bulk Analyze
              </button>
              
              <button id="open-dashboard" class="action-button" style="
                padding: 14px;
                background: #667eea;
                color: white;
                border: none;
                border-radius: 6px;
                font-size: 13px;
                font-weight: 600;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 6px;
                transition: all 0.2s;
              ">
                <span>📈</span> Full Dashboard
              </button>
              
              <button id="quick-route" class="action-button" style="
                padding: 14px;
                background: #ed8936;
                color: white;
                border: none;
                border-radius: 6px;
                font-size: 13px;
                font-weight: 600;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 6px;
                transition: all 0.2s;
              ">
                <span>🗺️</span> Today's Route
              </button>
            </div>
          </div>
          
          <!-- Automation Status -->
          ${storage.automationEnabled ? `
            <div style="
              background: #e6fffa;
              border: 1px solid #81e6d9;
              border-radius: 6px;
              padding: 12px;
              margin-bottom: 16px;
            ">
              <div style="font-size: 12px; color: #234e52; font-weight: 600; margin-bottom: 8px;">
                🤖 Automation Active
              </div>
              <div style="font-size: 11px; color: #2c5282;">
                ${storage.savedSearches?.filter(s => s.enabled).length || 0} searches running
                ${storage.automationStats?.lastScanTime ? 
                  ` • Last scan ${new Date(storage.automationStats.lastScanTime).toLocaleTimeString()}` : 
                  ''
                }
              </div>
            </div>
          ` : ''}
          
          <!-- Feature Categories -->
          <div style="margin-bottom: 16px;">
            <h3 style="font-size: 14px; font-weight: 600; color: #2d3748; margin-bottom: 12px;">
              Active Feature Sets
            </h3>
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; font-size: 12px;">
              <div style="display: flex; align-items: center; gap: 6px;">
                <span style="color: #48bb78;">✓</span> Smart Discovery (8)
              </div>
              <div style="display: flex; align-items: center; gap: 6px;">
                <span style="color: #48bb78;">✓</span> ML Analysis (8)
              </div>
              <div style="display: flex; align-items: center; gap: 6px;">
                <span style="color: #48bb78;">✓</span> Deal Pipeline (8)
              </div>
              <div style="display: flex; align-items: center; gap: 6px;">
                <span style="color: #48bb78;">✓</span> Auto Negotiation (8)
              </div>
              <div style="display: flex; align-items: center; gap: 6px;">
                <span style="color: #48bb78;">✓</span> Route Planning (8)
              </div>
              <div style="display: flex; align-items: center; gap: 6px;">
                <span style="color: #48bb78;">✓</span> Inventory Mgmt (8)
              </div>
              <div style="display: flex; align-items: center; gap: 6px;">
                <span style="color: #48bb78;">✓</span> Financial Tools (8)
              </div>
              <div style="display: flex; align-items: center; gap: 6px;">
                <span style="color: #48bb78;">✓</span> Price Analytics (8)
              </div>
              <div style="display: flex; align-items: center; gap: 6px;">
                <span style="color: #48bb78;">✓</span> A/B Testing (8)
              </div>
              <div style="display: flex; align-items: center; gap: 6px;">
                <span style="color: #48bb78;">✓</span> Integrations (8)
              </div>
            </div>
          </div>
          
          <!-- Quick Links -->
          <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px;">
            <button id="open-settings" class="quick-link" style="
              padding: 8px;
              background: #f7fafc;
              color: #4a5568;
              border: 1px solid #e2e8f0;
              border-radius: 6px;
              font-size: 12px;
              cursor: pointer;
              transition: all 0.2s;
            ">⚙️ Settings</button>
            
            <button id="view-reports" class="quick-link" style="
              padding: 8px;
              background: #f7fafc;
              color: #4a5568;
              border: 1px solid #e2e8f0;
              border-radius: 6px;
              font-size: 12px;
              cursor: pointer;
              transition: all 0.2s;
            ">📊 Reports</button>
            
            <button id="get-help" class="quick-link" style="
              padding: 8px;
              background: #f7fafc;
              color: #4a5568;
              border: 1px solid #e2e8f0;
              border-radius: 6px;
              font-size: 12px;
              cursor: pointer;
              transition: all 0.2s;
            ">❓ Help</button>
          </div>
        </div>
        
        <!-- Footer -->
        <div style="
          padding: 12px 20px;
          background: #f7fafc;
          border-top: 1px solid #e2e8f0;
          font-size: 11px;
          color: #718096;
          display: flex;
          justify-content: space-between;
          align-items: center;
        ">
          <span>PC Arbitrage Pro v${chrome.runtime.getManifest().version}</span>
          <a href="#" id="check-updates" style="color: #667eea; text-decoration: none;">
            ${storage.updateStatus === 'available' ? '🔴 Update Available' : 'Check for updates'}
          </a>
        </div>
      </div>
      
      <style>
        @keyframes pulse {
          0% { opacity: 1; }
          50% { opacity: 0.5; }
          100% { opacity: 1; }
        }
        
        .action-button:hover {
          transform: translateY(-1px);
          box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .quick-link:hover {
          background: #edf2f7;
          border-color: #cbd5e0;
        }
        
        input:focus {
          outline: none;
          border-color: #667eea;
          box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
      </style>
    `;
    
    // Wire up automation toggle
    document.getElementById('automation-toggle').addEventListener('change', async (e) => {
      const enabled = e.target.checked;
      await chrome.runtime.sendMessage({
        action: enabled ? 'MAX_AUTO_ENABLE' : 'MAX_AUTO_DISABLE'
      });
      
      // Update visual state
      const slider = e.target.nextElementSibling;
      slider.style.backgroundColor = enabled ? '#48bb78' : '#cbd5e0';
      slider.firstElementChild.style.left = enabled ? '27px' : '3px';
      
      // Show notification
      const notification = document.createElement('div');
      notification.style = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${enabled ? '#48bb78' : '#718096'};
        color: white;
        padding: 12px 20px;
        border-radius: 6px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        font-size: 14px;
        z-index: 1000;
        animation: slideIn 0.3s ease;
      `;
      notification.textContent = `Max Auto ${enabled ? 'Enabled' : 'Disabled'}`;
      document.body.appendChild(notification);
      setTimeout(() => notification.remove(), 3000);
    });
    
    // Enhanced ROI Calculator with ML scoring
    document.getElementById('calc-btn').addEventListener('click', async () => {
      const price = parseFloat(document.getElementById('calc-price').value);
      const specs = document.getElementById('calc-specs').value;
      const resultDiv = document.getElementById('calc-result');
      
      if (!price || !specs) {
        resultDiv.style.display = 'none';
        return;
      }
      
      // Enhanced component detection and valuation
      let estimatedValue = 0;
      let components = { gpu: null, cpu: null, ram: null };
      const specLower = specs.toLowerCase();
      
      // GPU detection and pricing
      const gpuPrices = {
        '4090': 1800, '4080': 1200, '4070ti': 900, '4070': 600,
        '3090ti': 1000, '3090': 900, '3080ti': 800, '3080': 700,
        '3070ti': 600, '3070': 500, '3060ti': 400, '3060': 350,
        '2080ti': 500, '2080': 400, '2070': 300, '2060': 250
      };
      
      for (const [gpu, value] of Object.entries(gpuPrices)) {
        if (specLower.includes(gpu)) {
          estimatedValue += value;
          components.gpu = `RTX ${gpu.toUpperCase()}`;
          break;
        }
      }
      
      // CPU detection and pricing
      const cpuPatterns = {
        'i9-13': 500, 'i9-12': 400, 'i9-11': 350, 'i9-10': 300,
        'i7-13': 350, 'i7-12': 300, 'i7-11': 250, 'i7-10': 200,
        'i5-13': 250, 'i5-12': 200, 'i5-11': 150, 'i5-10': 120,
        'ryzen 9 7': 500, 'ryzen 9 5': 400, 'ryzen 7 7': 350, 'ryzen 7 5': 300,
        'ryzen 5 7': 250, 'ryzen 5 5': 200
      };
      
      for (const [cpu, value] of Object.entries(cpuPatterns)) {
        if (specLower.includes(cpu)) {
          estimatedValue += value;
          components.cpu = cpu.toUpperCase();
          break;
        }
      }
      
      // RAM detection
      const ramMatch = specLower.match(/(\d+)\s*gb/);
      if (ramMatch) {
        const ram = parseInt(ramMatch[1]);
        estimatedValue += ram * 5; // $5 per GB
        components.ram = `${ram}GB`;
      }
      
      // Add base system value
      estimatedValue += 300; // PSU, case, mobo, storage
      
      // Calculate metrics
      const profit = estimatedValue - price;
      const roi = (profit / price * 100).toFixed(1);
      const margin = (profit / estimatedValue * 100).toFixed(1);
      
      // Risk assessment
      let riskLevel = 'Low';
      let riskColor = '#48bb78';
      if (roi > 100) {
        riskLevel = 'High';
        riskColor = '#e53e3e';
      } else if (roi > 60) {
        riskLevel = 'Medium';
        riskColor = '#ed8936';
      }
      
      // ML Score (simplified)
      const mlScore = Math.min(100, Math.max(0, 
        50 + (roi / 2) - (riskLevel === 'High' ? 20 : 0) + (components.gpu ? 10 : 0)
      )).toFixed(0);
      
      resultDiv.style.display = 'block';
      resultDiv.innerHTML = `
        <div style="display: grid; gap: 12px;">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <span style="color: #718096;">Fair Market Value:</span>
            <span style="font-weight: 600; font-size: 16px;">$${estimatedValue.toLocaleString()}</span>
          </div>
          
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <span style="color: #718096;">Potential Profit:</span>
            <span style="font-weight: 600; color: ${profit > 0 ? '#48bb78' : '#e53e3e'};">
              $${Math.abs(profit).toLocaleString()} ${profit < 0 ? '⚠️' : '✓'}
            </span>
          </div>
          
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <span style="color: #718096;">ROI:</span>
            <span style="font-weight: 700; font-size: 18px; color: ${profit > 0 ? '#48bb78' : '#e53e3e'};">
              ${roi}%
            </span>
          </div>
          
          <div style="border-top: 1px solid #e2e8f0; padding-top: 12px; display: grid; gap: 8px;">
            <div style="display: flex; justify-content: space-between;">
              <span style="color: #718096; font-size: 12px;">Risk Level:</span>
              <span style="font-size: 12px; font-weight: 600; color: ${riskColor};">${riskLevel}</span>
            </div>
            <div style="display: flex; justify-content: space-between;">
              <span style="color: #718096; font-size: 12px;">ML Score:</span>
              <span style="font-size: 12px; font-weight: 600;">${mlScore}/100</span>
            </div>
            <div style="display: flex; justify-content: space-between;">
              <span style="color: #718096; font-size: 12px;">Margin:</span>
              <span style="font-size: 12px; font-weight: 600;">${margin}%</span>
            </div>
          </div>
          
          ${Object.values(components).some(c => c) ? `
            <div style="border-top: 1px solid #e2e8f0; padding-top: 12px;">
              <div style="font-size: 11px; color: #718096; margin-bottom: 4px;">Detected Components:</div>
              <div style="font-size: 12px;">
                ${components.gpu ? `• GPU: ${components.gpu}<br>` : ''}
                ${components.cpu ? `• CPU: ${components.cpu}<br>` : ''}
                ${components.ram ? `• RAM: ${components.ram}` : ''}
              </div>
            </div>
          ` : ''}
          
          <button onclick="chrome.runtime.sendMessage({ action: 'openDashboard' })" style="
            width: 100%;
            padding: 10px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
          ">View Full Analysis →</button>
        </div>
      `;
      
      // Save to history
      const history = await chrome.storage.local.get(['calculatorHistory']) || [];
      history.push({
        price,
        specs,
        estimatedValue,
        roi,
        timestamp: new Date().toISOString()
      });
      chrome.storage.local.set({ 
        calculatorHistory: history.slice(-100) // Keep last 100
      });
    });
    
    // Button handlers
    document.getElementById('scan-current').addEventListener('click', async () => {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'INJECT_SCANNER' });
        window.close();
      }
    });
    
    document.getElementById('bulk-analyze').addEventListener('click', () => {
      chrome.runtime.sendMessage({ action: 'openDashboard' });
      chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html#/scanner') });
      window.close();
    });
    
    document.getElementById('open-dashboard').addEventListener('click', () => {
      chrome.runtime.sendMessage({ action: 'openDashboard' });
      window.close();
    });
    
    document.getElementById('quick-route').addEventListener('click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html#/routes') });
      window.close();
    });
    
    document.getElementById('open-settings').addEventListener('click', () => {
      chrome.runtime.sendMessage({ action: 'openSettings' });
      window.close();
    });
    
    document.getElementById('view-features').addEventListener('click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html#/features') });
      window.close();
    });
    
    document.getElementById('view-reports').addEventListener('click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html#/analytics') });
      window.close();
    });
    
    document.getElementById('get-help').addEventListener('click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html#/help') });
      window.close();
    });
    
    document.getElementById('check-updates').addEventListener('click', async (e) => {
      e.preventDefault();
      const response = await chrome.runtime.sendMessage({ action: 'CHECK_FOR_UPDATES' });
      // Show inline notification
      e.target.textContent = 'Checking...';
      setTimeout(() => {
        e.target.textContent = storage.updateStatus === 'available' ? 
          '🔴 Update Available' : '✓ Up to date';
      }, 1000);
    });
  });

})();