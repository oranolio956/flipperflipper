
// Photo Capture Script
document.addEventListener('DOMContentLoaded', () => {
  const fileInput = document.getElementById('file-input');
  const uploadArea = document.querySelector('.upload-area');
  const resultsSection = document.getElementById('results');
  
  // Close button
  document.getElementById('close').addEventListener('click', () => {
    window.close();
  });
  
  // Upload area click
  uploadArea.addEventListener('click', () => {
    fileInput.click();
  });
  
  // Drag and drop
  uploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadArea.classList.add('dragover');
  });
  
  uploadArea.addEventListener('dragleave', () => {
    uploadArea.classList.remove('dragover');
  });
  
  uploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadArea.classList.remove('dragover');
    
    const files = e.dataTransfer.files;
    if (files.length > 0 && files[0].type.startsWith('image/')) {
      processImage(files[0]);
    }
  });
  
  // File input change
  fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
      processImage(e.target.files[0]);
    }
  });
  
  // Process image
  async function processImage(file) {
    // Show loading
    uploadArea.innerHTML = '<p>Processing image...</p>';
    
    // Simulate OCR processing
    setTimeout(() => {
      const specs = {
        cpu: 'Intel Core i7-10700K',
        gpu: 'NVIDIA RTX 3070',
        ram: '32GB DDR4 3200MHz',
        storage: '1TB NVMe SSD',
        psu: '750W 80+ Gold'
      };
      
      showResults(specs);
    }, 2000);
  }
  
  // Show results
  function showResults(specs) {
    document.getElementById('capture-area').style.display = 'none';
    resultsSection.style.display = 'block';
    
    const specsList = document.getElementById('specs-list');
    specsList.innerHTML = Object.entries(specs).map(([key, value]) => `
      <div class="spec-item">
        <label>${key.toUpperCase()}:</label>
        <span>${value}</span>
      </div>
    `).join('');
    
    document.getElementById('create-listing').addEventListener('click', async () => {
      // Save to storage
      const listing = {
        title: 'Gaming PC - ' + specs.cpu,
        components: specs,
        source: 'photo',
        createdAt: new Date().toISOString()
      };
      
      await chrome.runtime.sendMessage({
        type: 'SAVE_DEAL',
        deal: listing
      });
      
      // Open dashboard
      chrome.tabs.create({ url: 'dashboard.html' });
      window.close();
    });
  }
});
