
// Dashboard Script
document.addEventListener('DOMContentLoaded', async () => {
  // Load data
  const { deals = [] } = await chrome.storage.local.get('deals');
  
  // Calculate metrics
  const totalRevenue = deals
    .filter(d => d.stage === 'sold')
    .reduce((sum, d) => sum + (d.sellPrice || 0), 0);
  
  const activeDeals = deals.filter(d => d.stage !== 'sold' && d.stage !== 'lost').length;
  
  const wonDeals = deals.filter(d => d.stage === 'sold').length;
  const winRate = deals.length > 0 ? (wonDeals / deals.length * 100) : 0;
  
  const avgRoi = deals.length > 0 
    ? deals.reduce((sum, d) => sum + (d.roi || 0), 0) / deals.length 
    : 0;
  
  // Update UI
  document.querySelector('.metric-card:nth-child(1) .value').textContent = '$' + totalRevenue;
  document.querySelector('.metric-card:nth-child(2) .value').textContent = activeDeals;
  document.querySelector('.metric-card:nth-child(3) .value').textContent = avgRoi.toFixed(1) + '%';
  document.querySelector('.metric-card:nth-child(4) .value').textContent = winRate.toFixed(1) + '%';
  
  // Create chart
  const ctx = document.getElementById('performance-chart').getContext('2d');
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
      datasets: [{
        label: 'Revenue',
        data: [0, 500, 1200, totalRevenue],
        borderColor: '#2196F3',
        fill: false
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false
    }
  });
  
  // Navigation
  document.querySelectorAll('.sidebar a').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      document.querySelectorAll('.sidebar a').forEach(a => a.classList.remove('active'));
      link.classList.add('active');
      // Handle section switching
    });
  });
});
