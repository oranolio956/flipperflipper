/**
 * Dashboard App - Production Build
 * Full single-page application for PC Arbitrage
 */

(function() {
  'use strict';

  // Router
  class Router {
    constructor() {
      this.routes = {};
      this.currentRoute = null;
      window.addEventListener('hashchange', () => this.navigate());
    }

    add(path, handler) {
      this.routes[path] = handler;
      return this;
    }

    navigate() {
      const path = window.location.hash.slice(1) || '/';
      const handler = this.routes[path] || this.routes['/'];
      
      if (handler) {
        this.currentRoute = path;
        handler();
      }
    }

    init() {
      this.navigate();
    }
  }

  // App State
  const state = {
    scannedListings: [],
    savedSearches: [],
    deals: [],
    settings: {},
    automationEnabled: false
  };

  // Load state from storage
  async function loadState() {
    const data = await chrome.storage.local.get([
      'scannedListings',
      'savedSearches', 
      'deals',
      'settings',
      'automationEnabled'
    ]);
    
    Object.assign(state, data);
  }

  // Save state to storage
  async function saveState(key, value) {
    state[key] = value;
    await chrome.storage.local.set({ [key]: value });
  }

  // UI Components
  function renderLayout(content) {
    const root = document.getElementById('root');
    root.innerHTML = `
      <div style="display: flex; height: 100vh; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
        <!-- Sidebar -->
        <nav style="width: 240px; background: #1f2937; color: white; padding: 24px 0;">
          <div style="padding: 0 24px; margin-bottom: 32px;">
            <h1 style="font-size: 20px; font-weight: 600; margin: 0;">PC Arbitrage</h1>
            <div style="font-size: 12px; color: #9ca3af; margin-top: 4px;">v${chrome.runtime.getManifest().version}</div>
          </div>
          
          <div style="padding: 0 12px;">
            ${renderNavLink('/', 'Dashboard', window.location.hash === '#/' || window.location.hash === '')}
            ${renderNavLink('/scanner', 'Scanner', window.location.hash === '#/scanner')}
            ${renderNavLink('/pipeline', 'Pipeline', window.location.hash === '#/pipeline')}
            ${renderNavLink('/automation', 'Automation', window.location.hash === '#/automation')}
            ${renderNavLink('/analytics', 'Analytics', window.location.hash === '#/analytics')}
            ${renderNavLink('/settings', 'Settings', window.location.hash === '#/settings')}
          </div>
          
          <div style="position: absolute; bottom: 24px; left: 24px; right: 24px;">
            <div style="padding: 16px; background: #374151; border-radius: 8px;">
              <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
                <span style="font-size: 14px;">Max Auto</span>
                <span style="
                  width: 8px;
                  height: 8px;
                  background: ${state.automationEnabled ? '#10b981' : '#6b7280'};
                  border-radius: 50%;
                "></span>
              </div>
              <div style="font-size: 12px; color: #9ca3af;">
                ${state.automationEnabled ? 'Running' : 'Paused'}
              </div>
            </div>
          </div>
        </nav>
        
        <!-- Main Content -->
        <main style="flex: 1; overflow-y: auto; background: #f9fafb;">
          ${content}
        </main>
      </div>
    `;
  }

  function renderNavLink(path, label, active) {
    return `
      <a href="#${path}" style="
        display: block;
        padding: 10px 12px;
        margin-bottom: 4px;
        border-radius: 6px;
        color: ${active ? 'white' : '#d1d5db'};
        background: ${active ? '#3b82f6' : 'transparent'};
        text-decoration: none;
        font-size: 14px;
        font-weight: ${active ? '500' : '400'};
      ">${label}</a>
    `;
  }

  // Pages
  function renderDashboard() {
    const stats = {
      revenue: state.deals.filter(d => d.status === 'sold').reduce((sum, d) => sum + (d.profit || 0), 0),
      activeDeals: state.deals.filter(d => ['sourced', 'negotiating', 'purchased'].includes(d.status)).length,
      avgRoi: state.deals.length > 0 ? 
        state.deals.reduce((sum, d) => sum + (d.roi || 0), 0) / state.deals.length : 0,
      winRate: state.deals.length > 0 ?
        state.deals.filter(d => d.status === 'sold').length / state.deals.length * 100 : 0
    };

    const content = `
      <div style="padding: 32px;">
        <h2 style="font-size: 24px; font-weight: 600; margin-bottom: 24px;">Dashboard</h2>
        
        <!-- Stats Grid -->
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 24px; margin-bottom: 32px;">
          <div style="background: white; padding: 24px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
            <div style="font-size: 14px; color: #6b7280; margin-bottom: 8px;">Total Revenue</div>
            <div style="font-size: 32px; font-weight: 600; color: #111827;">$${stats.revenue.toLocaleString()}</div>
          </div>
          
          <div style="background: white; padding: 24px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
            <div style="font-size: 14px; color: #6b7280; margin-bottom: 8px;">Active Deals</div>
            <div style="font-size: 32px; font-weight: 600; color: #111827;">${stats.activeDeals}</div>
          </div>
          
          <div style="background: white; padding: 24px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
            <div style="font-size: 14px; color: #6b7280; margin-bottom: 8px;">Avg ROI</div>
            <div style="font-size: 32px; font-weight: 600; color: #111827;">${stats.avgRoi.toFixed(0)}%</div>
          </div>
          
          <div style="background: white; padding: 24px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
            <div style="font-size: 14px; color: #6b7280; margin-bottom: 8px;">Win Rate</div>
            <div style="font-size: 32px; font-weight: 600; color: #111827;">${stats.winRate.toFixed(0)}%</div>
          </div>
        </div>
        
        <!-- Recent Candidates -->
        <div style="background: white; padding: 24px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
          <h3 style="font-size: 18px; font-weight: 600; margin-bottom: 16px;">Recent Candidates</h3>
          <div style="display: grid; gap: 12px;">
            ${state.scannedListings.slice(0, 5).map(listing => `
              <div style="
                padding: 16px;
                border: 1px solid #e5e7eb;
                border-radius: 6px;
                display: flex;
                justify-content: space-between;
                align-items: center;
              ">
                <div>
                  <div style="font-weight: 500; margin-bottom: 4px;">${listing.title}</div>
                  <div style="font-size: 14px; color: #6b7280;">
                    ${listing.platform} • ${listing.location || 'Unknown location'}
                  </div>
                </div>
                <div style="text-align: right;">
                  <div style="font-size: 18px; font-weight: 600; color: #059669;">
                    $${listing.price.toLocaleString()}
                  </div>
                  ${listing.roi ? `
                    <div style="font-size: 14px; color: #6b7280;">
                      ${(listing.roi * 100).toFixed(0)}% ROI
                    </div>
                  ` : ''}
                </div>
              </div>
            `).join('') || '<div style="color: #6b7280;">No recent scans</div>'}
          </div>
        </div>
      </div>
    `;
    
    renderLayout(content);
  }

  function renderScanner() {
    const content = `
      <div style="padding: 32px;">
        <div style="display: flex; justify-content: between; align-items: center; margin-bottom: 24px;">
          <h2 style="font-size: 24px; font-weight: 600;">Scanner Results</h2>
          <button onclick="window.scanCurrentTab()" style="
            padding: 10px 20px;
            background: #3b82f6;
            color: white;
            border: none;
            border-radius: 6px;
            font-weight: 500;
            cursor: pointer;
          ">Scan Current Tab</button>
        </div>
        
        <div style="background: white; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
          <div style="padding: 16px; border-bottom: 1px solid #e5e7eb;">
            <input type="text" placeholder="Search listings..." style="
              width: 100%;
              padding: 8px 12px;
              border: 1px solid #e5e7eb;
              border-radius: 6px;
              font-size: 14px;
            ">
          </div>
          
          <div style="padding: 16px;">
            ${state.scannedListings.length > 0 ? `
              <div style="display: grid; gap: 12px;">
                ${state.scannedListings.map(listing => `
                  <div style="
                    padding: 16px;
                    border: 1px solid #e5e7eb;
                    border-radius: 6px;
                    cursor: pointer;
                  " onclick="window.open('${listing.url}', '_blank')">
                    <div style="display: flex; justify-content: space-between;">
                      <div style="flex: 1;">
                        <div style="font-weight: 500; margin-bottom: 4px;">${listing.title}</div>
                        <div style="font-size: 14px; color: #6b7280;">
                          ${listing.platform} • ${listing.location || 'Unknown'} • 
                          ${new Date(listing.scannedAt).toLocaleDateString()}
                        </div>
                      </div>
                      <div style="text-align: right;">
                        <div style="font-size: 20px; font-weight: 600; color: #059669;">
                          $${listing.price.toLocaleString()}
                        </div>
                      </div>
                    </div>
                  </div>
                `).join('')}
              </div>
            ` : `
              <div style="text-align: center; padding: 48px; color: #6b7280;">
                <div style="font-size: 48px; margin-bottom: 16px;">📡</div>
                <div style="font-size: 18px; margin-bottom: 8px;">No listings scanned yet</div>
                <div>Visit a marketplace and click "Scan This Page"</div>
              </div>
            `}
          </div>
        </div>
      </div>
    `;
    
    renderLayout(content);
  }

  function renderAutomation() {
    const content = `
      <div style="padding: 32px;">
        <h2 style="font-size: 24px; font-weight: 600; margin-bottom: 24px;">Automation Center</h2>
        
        <!-- Max Auto Toggle -->
        <div style="background: white; padding: 24px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 24px;">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
              <h3 style="font-size: 18px; font-weight: 600; margin-bottom: 4px;">Max Auto Engine</h3>
              <p style="color: #6b7280; margin: 0;">Automatically scan saved searches on a schedule</p>
            </div>
            <button onclick="window.toggleAutomation()" style="
              padding: 10px 20px;
              background: ${state.automationEnabled ? '#dc2626' : '#10b981'};
              color: white;
              border: none;
              border-radius: 6px;
              font-weight: 500;
              cursor: pointer;
            ">${state.automationEnabled ? 'Disable' : 'Enable'}</button>
          </div>
        </div>
        
        <!-- Saved Searches -->
        <div style="background: white; padding: 24px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
            <h3 style="font-size: 18px; font-weight: 600;">Saved Searches</h3>
            <button onclick="window.addSearch()" style="
              padding: 8px 16px;
              background: #3b82f6;
              color: white;
              border: none;
              border-radius: 6px;
              font-size: 14px;
              font-weight: 500;
              cursor: pointer;
            ">Add Search</button>
          </div>
          
          ${state.savedSearches.length > 0 ? `
            <div style="display: grid; gap: 12px;">
              ${state.savedSearches.map(search => `
                <div style="
                  padding: 16px;
                  border: 1px solid #e5e7eb;
                  border-radius: 6px;
                ">
                  <div style="display: flex; justify-content: space-between; align-items: start;">
                    <div style="flex: 1;">
                      <div style="font-weight: 500; margin-bottom: 4px;">${search.name}</div>
                      <div style="font-size: 14px; color: #6b7280; margin-bottom: 8px;">
                        ${search.platform} • Every ${search.cadenceMinutes} minutes
                      </div>
                      <div style="font-size: 12px; color: #6b7280;">
                        ${search.url}
                      </div>
                    </div>
                    <div style="display: flex; gap: 8px;">
                      <button onclick="window.testScan('${search.id}')" style="
                        padding: 6px 12px;
                        background: #f3f4f6;
                        color: #374151;
                        border: none;
                        border-radius: 4px;
                        font-size: 12px;
                        cursor: pointer;
                      ">Test</button>
                      <button onclick="window.toggleSearch('${search.id}')" style="
                        padding: 6px 12px;
                        background: ${search.enabled ? '#fef3c7' : '#f3f4f6'};
                        color: ${search.enabled ? '#d97706' : '#374151'};
                        border: none;
                        border-radius: 4px;
                        font-size: 12px;
                        cursor: pointer;
                      ">${search.enabled ? 'Pause' : 'Resume'}</button>
                    </div>
                  </div>
                </div>
              `).join('')}
            </div>
          ` : `
            <div style="text-align: center; padding: 32px; color: #6b7280;">
              <div>No saved searches yet</div>
            </div>
          `}
        </div>
      </div>
    `;
    
    renderLayout(content);
  }

  function renderSettings() {
    const content = `
      <div style="padding: 32px;">
        <h2 style="font-size: 24px; font-weight: 600; margin-bottom: 24px;">Settings</h2>
        
        <div style="background: white; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
          <div style="border-bottom: 1px solid #e5e7eb;">
            <div style="display: flex; gap: 24px; padding: 0 24px;">
              <button class="settings-tab active" data-tab="general" style="
                padding: 16px 0;
                border: none;
                background: none;
                font-size: 14px;
                font-weight: 500;
                cursor: pointer;
                border-bottom: 2px solid #3b82f6;
              ">General</button>
              <button class="settings-tab" data-tab="financial" style="
                padding: 16px 0;
                border: none;
                background: none;
                font-size: 14px;
                font-weight: 500;
                cursor: pointer;
                color: #6b7280;
                border-bottom: 2px solid transparent;
              ">Financial</button>
              <button class="settings-tab" data-tab="automation" style="
                padding: 16px 0;
                border: none;
                background: none;
                font-size: 14px;
                font-weight: 500;
                cursor: pointer;
                color: #6b7280;
                border-bottom: 2px solid transparent;
              ">Automation</button>
            </div>
          </div>
          
          <div style="padding: 24px;">
            <div id="settings-content">
              <!-- General Settings -->
              <div>
                <div style="margin-bottom: 24px;">
                  <label style="display: block; font-size: 14px; font-weight: 500; margin-bottom: 8px;">
                    Theme
                  </label>
                  <select style="
                    width: 100%;
                    padding: 8px 12px;
                    border: 1px solid #e5e7eb;
                    border-radius: 6px;
                    font-size: 14px;
                  ">
                    <option>Light</option>
                    <option>Dark</option>
                    <option>Auto</option>
                  </select>
                </div>
                
                <div style="margin-bottom: 24px;">
                  <label style="display: block; font-size: 14px; font-weight: 500; margin-bottom: 8px;">
                    Currency
                  </label>
                  <select style="
                    width: 100%;
                    padding: 8px 12px;
                    border: 1px solid #e5e7eb;
                    border-radius: 6px;
                    font-size: 14px;
                  ">
                    <option>USD ($)</option>
                    <option>EUR (€)</option>
                    <option>GBP (£)</option>
                  </select>
                </div>
                
                <button style="
                  padding: 10px 20px;
                  background: #3b82f6;
                  color: white;
                  border: none;
                  border-radius: 6px;
                  font-weight: 500;
                  cursor: pointer;
                ">Save Changes</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
    
    renderLayout(content);
  }

  // Global functions
  window.scanCurrentTab = async () => {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, { action: 'INJECT_SCANNER' });
    }
  };

  window.toggleAutomation = async () => {
    state.automationEnabled = !state.automationEnabled;
    await chrome.runtime.sendMessage({
      action: state.automationEnabled ? 'MAX_AUTO_ENABLE' : 'MAX_AUTO_DISABLE'
    });
    renderAutomation();
  };

  window.addSearch = () => {
    const name = prompt('Search name:');
    const url = prompt('Search URL:');
    const cadence = prompt('Check every X minutes:', '30');
    
    if (name && url && cadence) {
      const search = {
        id: `search-${Date.now()}`,
        name,
        url,
        platform: url.includes('facebook') ? 'facebook' : 
                  url.includes('craigslist') ? 'craigslist' : 'offerup',
        enabled: true,
        cadenceMinutes: parseInt(cadence),
        createdAt: new Date().toISOString()
      };
      
      state.savedSearches.push(search);
      saveState('savedSearches', state.savedSearches);
      renderAutomation();
    }
  };

  window.testScan = async (searchId) => {
    await chrome.runtime.sendMessage({
      action: 'MAX_AUTO_TEST_SCAN',
      searchId
    });
    alert('Test scan initiated. Check the Scanner page for results.');
  };

  window.toggleSearch = (searchId) => {
    const search = state.savedSearches.find(s => s.id === searchId);
    if (search) {
      search.enabled = !search.enabled;
      saveState('savedSearches', state.savedSearches);
      renderAutomation();
    }
  };

  // Initialize
  const router = new Router();
  
  router
    .add('/', renderDashboard)
    .add('/scanner', renderScanner)
    .add('/pipeline', () => renderLayout('<div style="padding: 32px;"><h2>Pipeline - Coming Soon</h2></div>'))
    .add('/automation', renderAutomation)
    .add('/analytics', () => renderLayout('<div style="padding: 32px;"><h2>Analytics - Coming Soon</h2></div>'))
    .add('/settings', renderSettings);

  // Load state and start
  loadState().then(() => {
    router.init();
  });

})();