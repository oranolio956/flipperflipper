/**
 * OfferUp Content Script
 * Full functionality for scanning and parsing listings
 */

(function() {
  'use strict';

  console.log('PC Arbitrage: OfferUp content script loaded');

  // Parse OfferUp listing card
  function parseListingCard(element) {
    try {
      const titleElement = element.querySelector('[data-testid="item-title"], h3, [role="heading"]');
      const priceElement = element.querySelector('[data-testid="item-price"], span[aria-label*="price"]');
      const linkElement = element.querySelector('a[href*="/item/"]');
      const imageElement = element.querySelector('img[loading="lazy"]');
      
      if (!titleElement || !priceElement || !linkElement) return null;
      
      const title = titleElement.textContent.trim();
      const priceText = priceElement.textContent.trim();
      const price = parseFloat(priceText.replace(/[^0-9.]/g, ''));
      const link = linkElement.href;
      const image = imageElement?.src || '';
      
      // Extract item ID
      const idMatch = link.match(/\/item\/detail\/(\d+)/);
      const id = idMatch ? idMatch[1] : Date.now().toString();
      
      // Check if it's a gaming PC
      const gamingKeywords = ['gaming', 'pc', 'rtx', 'gtx', 'ryzen', 'intel', 'nvidia', 'desktop', 'computer'];
      const isGamingPC = gamingKeywords.some(keyword => 
        title.toLowerCase().includes(keyword)
      );
      
      if (!isGamingPC || price < 100 || price > 10000) return null;
      
      return {
        id: `ou-${id}`,
        platform: 'offerup',
        title,
        price,
        link,
        image,
        location: 'Unknown',
        postedDate: new Date().toISOString(),
        seller: { name: 'OfferUp Seller' }
      };
    } catch (error) {
      console.error('Error parsing listing:', error);
      return null;
    }
  }

  // Scan the current page
  function scanPage() {
    console.log('Scanning OfferUp...');
    const listings = [];
    
    // Find all listing cards
    const listingElements = document.querySelectorAll('[data-testid="item-card"], article, [role="article"]');
    
    listingElements.forEach(element => {
      const listing = parseListingCard(element);
      if (listing) {
        listings.push(listing);
      }
    });
    
    console.log(`Found ${listings.length} gaming PC listings`);
    return listings;
  }

  // Inject scanner overlay (same UI as Facebook)
  function injectScanner() {
    if (document.getElementById('pc-arbitrage-scanner')) return;
    
    const scanner = document.createElement('div');
    scanner.id = 'pc-arbitrage-scanner';
    scanner.innerHTML = `
      <div style="
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: #667eea;
        color: white;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        z-index: 9999;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        max-width: 350px;
      ">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
          <h3 style="margin: 0; font-size: 18px;">PC Arbitrage Scanner</h3>
          <button id="scanner-close" style="
            background: none;
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
            padding: 0;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
          ">×</button>
        </div>
        
        <div id="scanner-status" style="margin-bottom: 15px; font-size: 14px;">
          Ready to scan for gaming PC deals
        </div>
        
        <button id="scan-button" style="
          width: 100%;
          padding: 12px;
          background: white;
          color: #667eea;
          border: none;
          border-radius: 8px;
          font-size: 16px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
        ">Scan This Page</button>
        
        <div id="scan-results" style="
          margin-top: 15px;
          max-height: 200px;
          overflow-y: auto;
          display: none;
        "></div>
        
        <div style="
          margin-top: 15px;
          padding-top: 15px;
          border-top: 1px solid rgba(255,255,255,0.2);
          display: flex;
          gap: 10px;
        ">
          <button id="open-dashboard-btn" style="
            flex: 1;
            padding: 8px;
            background: rgba(255,255,255,0.2);
            color: white;
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 6px;
            font-size: 14px;
            cursor: pointer;
          ">Dashboard</button>
          <button id="open-settings-btn" style="
            flex: 1;
            padding: 8px;
            background: rgba(255,255,255,0.2);
            color: white;
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 6px;
            font-size: 14px;
            cursor: pointer;
          ">Settings</button>
        </div>
      </div>
    `;
    
    document.body.appendChild(scanner);
    
    // Wire up buttons
    document.getElementById('scanner-close').addEventListener('click', () => {
      scanner.remove();
    });
    
    document.getElementById('scan-button').addEventListener('click', async () => {
      const statusEl = document.getElementById('scanner-status');
      const resultsEl = document.getElementById('scan-results');
      const button = document.getElementById('scan-button');
      
      button.disabled = true;
      button.textContent = 'Scanning...';
      statusEl.textContent = 'Scanning page for gaming PCs...';
      
      const listings = scanPage();
      
      if (listings.length > 0) {
        // Send to background
        chrome.runtime.sendMessage({
          action: 'STORE_SCAN_RESULTS',
          listings: listings
        });
        
        statusEl.textContent = `Found ${listings.length} gaming PCs!`;
        resultsEl.style.display = 'block';
        resultsEl.innerHTML = listings.map(l => `
          <div style="
            padding: 8px;
            margin-bottom: 8px;
            background: rgba(255,255,255,0.1);
            border-radius: 6px;
            font-size: 13px;
          ">
            <div style="font-weight: 600;">${l.title}</div>
            <div>$${l.price.toLocaleString()}</div>
          </div>
        `).join('');
      } else {
        statusEl.textContent = 'No gaming PCs found on this page';
      }
      
      button.disabled = false;
      button.textContent = 'Scan Again';
    });
    
    document.getElementById('open-dashboard-btn').addEventListener('click', () => {
      chrome.runtime.sendMessage({ action: 'openDashboard' });
    });
    
    document.getElementById('open-settings-btn').addEventListener('click', () => {
      chrome.runtime.sendMessage({ action: 'openSettings' });
    });
  }

  // Listen for messages
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('OfferUp content script received:', request.action);
    
    if (request.action === 'SCAN_PAGE') {
      const listings = scanPage();
      sendResponse({ listings });
    } else if (request.action === 'INJECT_SCANNER') {
      injectScanner();
      sendResponse({ success: true });
    } else if (request.action === 'PING') {
      sendResponse({ pong: true });
    }
    
    return true;
  });

  // Auto-inject on search pages
  if (window.location.pathname.includes('/search')) {
    setTimeout(() => {
      console.log('Auto-injecting scanner on search page');
      injectScanner();
    }, 2000);
  }

})();